const {X,ex,on,r,sr}=require('./test.js');
r.id='r1';
for (const style of ['boombap','trap']) for (const amount of [0,0.5,1]){
  const o={bars:64,style,amount,locks:{kick:false,snare:amount===1,hat:false,perc:false},seed:42,phrase:8,humanizeMs:2,bpm:90};
  const t0=Date.now();const g=X.generateBeat(r,o);const g2=X.generateBeat(r,o);
  const same=JSON.stringify(g)===JSON.stringify(g2);
  const kinds={};g.plan.forEach(p=>kinds[p.kind]=(kinds[p.kind]||0)+1);
  const tags={};g.events.forEach(e=>tags[e.tag]=(tags[e.tag]||0)+1);
  // snare locked check: compare snare events vs base
  let lockOk=true; if(o.locks.snare){ const base=r.hits.filter(h=>h.lane==='snare'); for(let b=0;b<64;b++){ const sn=g.events.filter(e=>e.lane==='snare'&&e.pos>=b*4-0.05&&e.pos<b*4+4-0.05&&e.tag!=='end'); if(sn.length!==base.filter(h=>Math.floor(h.pos/4)===b%r.bars).length) {lockOk=false;} } }
  console.log(style,amount,'events',g.events.length,'det',same,'plan',JSON.stringify(kinds),'tags',JSON.stringify(tags),'lockOk',lockOk,Date.now()-t0+'ms');
}
// show first 16 bars plan + a fill bar
const g=X.generateBeat(r,{bars:32,style:'boombap',amount:0.6,locks:{},seed:7,phrase:8,humanizeMs:0,bpm:90});
console.log(g.plan.map(p=>p.kind[0]+p.sec).join(' '));
const fillBar=g.plan.find(p=>p.kind==='fill');
if(fillBar) console.log('fill bar',fillBar.bar, g.events.filter(e=>e.pos>=fillBar.bar*4&&e.pos<fillBar.bar*4+4).map(e=>e.lane[0]+(e.pos-fillBar.bar*4).toFixed(2)+':'+e.tag).join(' '));
// render
const kit=X.builtinKit(sr), seq=X.generateBeat(r,{bars:360/4*3,style:'boombap',amount:0.5,locks:{},seed:1,phrase:8,humanizeMs:2,bpm:90});
let t0=Date.now();const out=X.renderEvents(seq,kit,{sr,bpm:90,fallback:kit,layer:{on:true,mode:'strong',db:-3,offsetMs:0,lengthMs:300,sound:X.hardKick(sr),picked:[]}});
console.log('render',(out.n/sr).toFixed(1)+'s', Date.now()-t0+'ms');
t0=Date.now();const m=X.master(out.L,out.R,0.3);console.log('master',Date.now()-t0+'ms',m);
let pk=0;for(let i=0;i<out.n;i++)pk=Math.max(pk,Math.abs(out.L[i]));console.log('peak',pk.toFixed(3),'nan?',out.L.some(isNaN));
// wav roundtrip
const w=X.encodeWav([out.L.subarray(0,1000),out.R.subarray(0,1000)],sr,24);const d=X.decodeWav(w);
let err=0;for(let i=0;i<1000;i++)err=Math.max(err,Math.abs(d.ch[0][i]-out.L[i]));console.log('wav rt err',err, d.sr, d.ch.length);
// midi
const mid=X.encodeMidi(seq,90,'Test',{on:true,mode:'strong',offsetMs:0});require('fs').writeFileSync('/tmp/claude-0/-home-user-hidden-motives/ab007557-317c-5cfd-927f-dfb9af25e803/scratchpad/nb/test.mid',mid);console.log('midi bytes',mid.length);
// kit pack roundtrip
const pk2=X.unpackKit(JSON.parse(JSON.stringify(X.packKit({id:'k',name:'K',lanes:kit.lanes}))));console.log('kit rt',Object.keys(pk2.lanes).map(l=>l+pk2.lanes[l].length).join(','), pk2.lanes.kick[0].ch[0].length===kit.lanes.kick[0].ch[0].length);
// slices
const sl=X.suggestSlices(ex.ch,sr,on);sl.slice(0,6).forEach(s=>console.log(s.lane,((s.end-s.start)/sr*1000).toFixed(0)+'ms',X.sliceFlags(s,on,X.envelope(X.toMono(ex.ch),sr,25),sr).map(f=>f.k).join(',')));
const zp=X.zipParts([{name:'a.wav',data:w},{name:'b.mid',data:mid}]);require('fs').writeFileSync('/tmp/claude-0/-home-user-hidden-motives/ab007557-317c-5cfd-927f-dfb9af25e803/scratchpad/nb/test.zip',Buffer.concat(zp.map(p=>Buffer.from(p))));

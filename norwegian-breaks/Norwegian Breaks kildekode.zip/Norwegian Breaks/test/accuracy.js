const {X}=require('./test.js');
const sr=44100, kit=X.builtinKit(sr);
function score(label, seq, opt, bpm){
  const out=X.renderEvents(seq,kit,{sr,bpm,fallback:kit,...opt}); X.master(out.L,out.R,opt.glue||0);
  const on=X.analyzeLoop([out.L,out.R],sr,{}); const spb=60/bpm;
  let hit=0,miss=0,wrong=0,extra=0; const used=new Set();
  // group truth by time
  const truth=seq.events.filter(e=>e.pos*spb<out.n/sr-0.05);
  truth.forEach(e=>{ const t=e.pos*spb; const o=on.find(o=>Math.abs(o.t-t)<0.02); if(!o){miss++;return;} used.add(o); if(o.labels.includes(e.lane)||(e.lane==='ohat'&&o.labels.includes('hat'))) hit++; else {wrong++; if(process.env.V) console.log('  wrong',e.lane,e.pos.toFixed(2),'->',o.labels.join('+'),o.norm.map(v=>v.toFixed(2)).join(','));} });
  extra=on.filter(o=>!used.has(o)).length;
  console.log(label.padEnd(28),'truth',truth.length,'labelled right',hit,'wrong lane',wrong,'missed',miss,'extra onsets',extra);
}
const r={bpm:88,bars:2,hits:[]};
const ex=X.exampleLoop(sr); const on=X.analyzeLoop(ex.ch,sr,{}); r.hits=X.rhythmFromOnsets(on,88,2,0);
// truth rhythm = generated beat from the detected rhythm, rendered again
for (const amt of [0,0.6]){
 const seq=X.generateBeat(r,{bars:4,style:'boombap',amount:amt,locks:{},seed:3,phrase:4,humanizeMs:1,bpm:88});
 score('plain amt '+amt, seq, {}, 88);
 score('layer+glue amt '+amt, seq, {glue:0.4, layer:{on:true,mode:'strong',db:-2,offsetMs:0,lengthMs:420,sound:X.hardKick(sr),picked:[]}}, 88);
 const t=X.generateBeat(r,{bars:4,style:'trap',amount:amt,locks:{},seed:5,phrase:4,humanizeMs:0,bpm:140});
 score('trap 140 amt '+amt, t, {}, 140);
}

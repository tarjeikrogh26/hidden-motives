const { chromium } = require(require('child_process').execSync('npm root -g').toString().trim()+'/playwright');
const D=__dirname;
(async()=>{
  const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});
  const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:2,acceptDownloads:true,colorScheme:process.argv[2]||'light'});
  const p=await ctx.newPage(); const errs=[];
  p.on('console',m=>{if(m.type()==='error'||m.type()==='warning')errs.push(m.type()+': '+m.text())}); p.on('pageerror',e=>errs.push('PAGEERR '+e.message));
  await p.goto('file://'+D+'/standalone.html'); await p.waitForTimeout(800);
  await p.screenshot({path:D+'/shots/1loop.png',fullPage:true});
  await p.click('#goRhythm'); await p.waitForTimeout(300);
  // tap an empty spot in the perc row and a hit
  const box=await p.locator('#rhGrid').boundingBox();
  await p.mouse.click(box.x+26*6+13, box.y+20+34*4+17); await p.waitForTimeout(200);
  console.log('panel', await p.locator('#hitTitle').textContent());
  await p.click('#rhPlayKit'); await p.waitForTimeout(500); console.log('dock', await p.locator('#dockWhat').textContent(), await p.locator('#dockTime').textContent());
  await p.screenshot({path:D+'/shots/2rhythm.png',fullPage:true});
  await p.click('#rhSave'); await p.waitForTimeout(200); console.log(await p.locator('#rhSaved').textContent());
  const [d1]=await Promise.all([p.waitForEvent('download'),p.click('#rhMidi')]); console.log('dl',d1.suggestedFilename());
  await p.click('.steps button[data-v=sounds]'); await p.waitForTimeout(300);
  await p.click('#slAuto'); await p.waitForTimeout(200);
  await p.screenshot({path:D+'/shots/3sounds.png',fullPage:true});
  // drag end handle in zoom
  const zb=await p.locator('#slZoomBox').boundingBox();
  await p.click('#slSave'); await p.waitForTimeout(300); console.log(await p.locator('#slSaved').textContent());
  await p.click('.steps button[data-v=combine]'); await p.waitForTimeout(300);
  await p.click('#lyOn'); await p.click('#lyMode button[data-v=pick]'); await p.waitForTimeout(100);
  const picks=await p.locator('#lyPicks button').count(); console.log('kick picks',picks); if(picks) await p.locator('#lyPicks button').first().click();
  await p.click('#cbPlay'); await p.waitForTimeout(400);
  await p.screenshot({path:D+'/shots/4combine.png',fullPage:true});
  await p.click('#cbSave'); await p.waitForTimeout(200); console.log(await p.locator('#cbSaved').textContent());
  await p.click('.steps button[data-v=beat]'); await p.waitForTimeout(200);
  await p.click('#gMake'); await p.waitForSelector('#gRes:not([hidden])'); await p.waitForTimeout(800);
  console.log('dock', await p.locator('#dockWhat').textContent(), await p.locator('#dockTime').textContent());
  await p.click('#gKeep'); await p.click('#gAgain'); await p.waitForTimeout(1500);
  console.log('versions', await p.locator('#gVers li').count());
  await p.screenshot({path:D+'/shots/5beat.png',fullPage:true});
  const [d2]=await Promise.all([p.waitForEvent('download',{timeout:60000}),p.click('#exMix')]); await d2.saveAs(D+'/dl3/'+d2.suggestedFilename()); console.log('dl',d2.suggestedFilename());
  const [d3]=await Promise.all([p.waitForEvent('download',{timeout:60000}),p.click('#exStems')]); await d3.saveAs(D+'/dl3/'+d3.suggestedFilename()); console.log('dl',d3.suggestedFilename());
  await p.click('#gSaveProj'); await p.waitForTimeout(300);
  await p.click('.steps button[data-v=lib]'); await p.waitForTimeout(300);
  await p.screenshot({path:D+'/shots/6lib.png',fullPage:true});
  const [d4]=await Promise.all([p.waitForEvent('download'),p.locator('#libProj .li button[data-a=file]').first().click()]); await d4.saveAs(D+'/dl3/'+d4.suggestedFilename()); console.log('dl',d4.suggestedFilename());
  // reload page → library persisted? then import project file
  await p.reload(); await p.waitForTimeout(800); await p.click('.steps button[data-v=lib]');
  console.log('after reload projects', await p.locator('#libProj .li').count(), 'kits', await p.locator('#libKits .li').count());
  await p.locator('#libProj .li button[data-a=open]').first().click(); await p.waitForTimeout(1500);
  console.log('opened view', await p.evaluate(()=>ST.view), 'versions', await p.locator('#gVers li').count());
  await p.setInputFiles('#impFile', D+'/dl3/'+d4.suggestedFilename()); await p.waitForTimeout(800); console.log('toast', await p.locator('#toast').textContent());
  // load a real file through the loop input (the exported wav)
  await p.click('.steps button[data-v=loop]');
  console.log(errs.length?errs.join('\n'):'no console errors');
  await b.close();
})().catch(e=>{console.error('FAIL',e);process.exit(1)});

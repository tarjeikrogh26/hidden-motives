/* ================= UI ================= */
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
const tick = () => new Promise(r => setTimeout(r, 30));
const fmtTime = s => { s = Math.max(0, s); const m = Math.floor(s / 60), r = Math.floor(s % 60); return m + ':' + String(r).padStart(2, '0'); };
const fmtMs = v => { v = Math.round(v); return (v > 0 ? '+' : v < 0 ? '−' : '±') + Math.abs(v) + ' ms'; };
const fmtDb = v => (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(Math.round(v * 2) / 2) + ' dB';
const clean = s => (s || '').replace(/[\\/:*?"<>|]+/g, '').replace(/\s+/g, ' ').trim().slice(0, 60);
/* Filenames stay plain ASCII: some browsers drop a download name with other characters. */
const fileBase = s => clean(String(s || '').replace(/×/g, 'x').replace(/[æÆ]/g, m => m === 'æ' ? 'ae' : 'Ae').replace(/[øØ]/g, m => m === 'ø' ? 'o' : 'O').normalize('NFKD').replace(/[^\x20-\x7e]/g, '')) || 'Norwegian Breaks';
const deepRh = r => ({ id:r.id, name:r.name, bpm:r.bpm, bars:r.bars, created:r.created || Date.now(), hits:r.hits.map(h => ({ ...h })) });
const lsGet = (k, d) => { try { const v = localStorage.getItem('nbreaks.' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem('nbreaks.' + k, JSON.stringify(v)); } catch (e) {} };

/* ---------- toast / busy ---------- */
let toastT = 0;
function toast(msg){ const t = $('#toast'); t.textContent = msg; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => { t.hidden = true; }, 3800); }
async function busy(msg, fn){
  $('#busyTxt').textContent = msg; $('#busy').hidden = false; await tick();
  try { return await fn(); } finally { $('#busy').hidden = true; }
}

/* ---------- audio ---------- */
let ctx = null;
function getCtx(){
  if (!ctx){
    const AC = window.AudioContext || window.webkitAudioContext;
    ctx = new AC();
    try { if (navigator.audioSession) navigator.audioSession.type = 'playback'; } catch (e) {}
  }
  return ctx;
}
const SR = () => getCtx().sampleRate;
function wake(){ const c = getCtx(); unlockAudio(); if (c.state !== 'running'){ try { c.resume(); } catch (e) {} } return c; }
/* iPhone: Web Audio stays silent with the ring switch on silent unless a media element also plays.
   A looping silent <audio> moves the page into the "playback" audio session. */
let unlocked = false;
function unlockAudio(){
  if (unlocked) return; unlocked = true;
  try { if (navigator.audioSession) navigator.audioSession.type = 'playback'; } catch (e) {}
  try {
    const sr = 8000, n = sr, buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf), w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, sr, true); v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
    const el = document.createElement('audio');
    el.setAttribute('playsinline', ''); el.setAttribute('webkit-playsinline', ''); el.loop = true; el.preload = 'auto';
    el.src = URL.createObjectURL(new Blob([buf], { type:'audio/wav' }));
    const p = el.play(); if (p && p.catch) p.catch(() => {});
  } catch (e) {}
  try { const c = getCtx(), b = c.createBuffer(1, 1, 22050), s = c.createBufferSource(); s.buffer = b; s.connect(c.destination); s.start(0); c.resume(); } catch (e) {}
}
['pointerdown', 'touchend', 'keydown'].forEach(ev => document.addEventListener(ev, unlockAudio, { capture:true, passive:true }));
function decode(ab){ const c = getCtx(); return new Promise((res, rej) => { try { const p = c.decodeAudioData(ab, res, rej); if (p && p.catch) p.catch(rej); } catch (e) { rej(e); } }); }
const chansOf = buf => { const out = []; for (let c = 0; c < Math.min(2, buf.numberOfChannels); c++) out.push(buf.getChannelData(c).slice()); return out; };

let BUILTIN = null, HARD = null;
function builtin(){ const sr = SR(); if (!BUILTIN || BUILTIN.lanes.kick[0].sr !== sr){ BUILTIN = builtinKit(sr); HARD = hardKick(sr); } return BUILTIN; }

/* one player for everything long, one-shots on top */
const PL = { src:null, t0:0, off:0, dur:0, loop:false, label:'', kind:'', bpm:0, raf:0 };
let shotSrc = null;
function stopPlay(){
  if (PL.src){ try { PL.src.onended = null; PL.src.stop(); } catch (e) {} }
  const wasBeat = PL.kind === 'beat';
  PL.src = null; PL.kind = ''; PL.ver = null; cancelAnimationFrame(PL.raf);
  if (wasBeat && ST.view === 'beat' && !PL.starting) setTimeout(renderBeat, 0);
  $('#dockBtn').disabled = true; $('#dockWhat').textContent = 'Nothing playing'; $('#dockTime').textContent = 'Tap ▶ anywhere to listen';
  setPlayLabels(); drawPlayheads();
}
function playBuf(chs, sr, o){
  PL.starting = true; stopPlay(); stopShot(); PL.starting = false;
  const c = wake(), b = c.createBuffer(chs.length, chs[0].length, sr);
  chs.forEach((x, i) => b.copyToChannel(x, i));
  const s = c.createBufferSource(); s.buffer = b; s.loop = !!o.loop; s.connect(c.destination);
  const from = Math.max(0, Math.min(o.from || 0, b.duration - 0.01)), now = c.currentTime + 0.03;
  s.start(now, from);
  Object.assign(PL, { src:s, t0:now, off:from, dur:b.duration, loop:!!o.loop, label:o.label, kind:o.kind, bpm:o.bpm || 0, total:o.total || b.duration });
  s.onended = () => { if (PL.src === s) stopPlay(); };
  $('#dockBtn').disabled = false; $('#dockWhat').textContent = o.label;
  setPlayLabels(); loopRaf();
}
function playPos(){ if (!PL.src || !ctx) return 0; let t = ctx.currentTime - PL.t0 + PL.off; if (t < PL.off && ctx.currentTime < PL.t0) t = PL.off; return PL.loop ? t % PL.dur : Math.min(t, PL.dur); }
function loopRaf(){
  cancelAnimationFrame(PL.raf);
  const step = () => {
    if (!PL.src) return;
    const t = playPos();
    let s = fmtTime(t) + ' / ' + fmtTime(PL.total);
    if (PL.bpm){ const beats = t / (60 / PL.bpm); s += ' · bar ' + (Math.floor(beats / 4) + 1) + '.' + (Math.floor(beats % 4) + 1); }
    $('#dockTime').textContent = s;
    drawPlayheads();
    PL.raf = requestAnimationFrame(step);
  };
  PL.raf = requestAnimationFrame(step);
}
function stopShot(){ if (shotSrc){ try { shotSrc.stop(); } catch (e) {} shotSrc = null; } }
function shot(chs, sr, gain = 1){
  stopShot();
  const c = wake(), b = c.createBuffer(chs.length, chs[0].length, sr); chs.forEach((x, i) => b.copyToChannel(x, i));
  const s = c.createBufferSource(), g = c.createGain(); g.gain.value = gain; s.buffer = b; s.connect(g); g.connect(c.destination); s.start(); shotSrc = s;
}
$('#dockBtn').onclick = stopPlay;
const PLAY_BTNS = { loop:'#playLoop', orig:'#rhPlayOrig', rhkit:'#rhPlayKit', combine:'#cbPlay', beat:'#gPlay' };
const PLAY_TXT = { loop:'Play loop', orig:'Original loop', rhkit:'Rhythm with', combine:'Play together', beat:'Play' };
function setPlayLabels(){ Object.entries(PLAY_BTNS).forEach(([k, s]) => { const b = $(s); if (b) b.textContent = (PL.kind === k ? '■ ' : '▶ ') + PLAY_TXT[k]; }); }

/* ---------- drawing helpers ---------- */
const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const laneCol = (l, a = 1) => 'hsl(' + css('--h-' + l) + ' ' + css('--pad-s') + ' ' + css('--pad-l') + (a < 1 ? ' / ' + a : '') + ')';
function fit(cv, w, h){ const d = window.devicePixelRatio || 1; cv.width = Math.max(1, Math.round(w * d)); cv.height = Math.max(1, Math.round(h * d)); cv.style.width = w + 'px'; cv.style.height = h + 'px'; const x = cv.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0); return x; }
function boxFit(cv){ const b = cv.parentElement; return { x:fit(cv, b.clientWidth, b.clientHeight), w:b.clientWidth, h:b.clientHeight }; }
function peaksOf(x, a, b, cols){
  const mn = new Float32Array(cols), mx = new Float32Array(cols), span = (b - a) / cols;
  for (let c = 0; c < cols; c++){
    const i0 = Math.floor(a + c * span), i1 = Math.max(i0 + 1, Math.floor(a + (c + 1) * span));
    let lo = 0, hi = 0; for (let i = Math.max(0, i0); i < Math.min(x.length, i1); i++){ const v = x[i]; if (v < lo) lo = v; if (v > hi) hi = v; }
    mn[c] = lo; mx[c] = hi;
  }
  return { mn, mx };
}
function drawWave(g, x, a, b, w, h, col){
  const p = peaksOf(x, a, b, Math.max(1, Math.floor(w))); g.fillStyle = col;
  for (let c = 0; c < p.mn.length; c++){ const y0 = h / 2 - p.mx[c] * h * 0.46, y1 = h / 2 - p.mn[c] * h * 0.46; g.fillRect(c, y0, 1, Math.max(1, y1 - y0)); }
}

/* ---------- state ---------- */
const ST = {
  view:'loop', loop:null, rh:null, rhEdited:false, sel:null, slices:[], ss:0,
  db:{ rhythms:[], kits:[], projects:[] },
  cb:{ rhId:'work', kitId:'builtin', fallback:true, layer:{ on:false, src:HARD_KICK_ID, mode:'strong', db:-4, offsetMs:0, lengthMs:420, followVel:true, picked:[] }, projName:'', projId:null },
  g:Object.assign({ style:'boombap', bpm:90, minutes:3, amount:35, locks:{ kick:false, snare:false, hat:false, perc:false }, phrase:8, hum:1.5, glue:25 }, lsGet('gen', {})),
  vers:[], cur:null, nVer:0, done:{}
};

/* ---------- storage (IndexedDB, this device) ---------- */
const DB = { db:null, mem:false };
function idbOpen(){ return new Promise((res, rej) => { const r = indexedDB.open('norwegian-breaks', 1); r.onupgradeneeded = () => { ['rhythms', 'kits', 'projects'].forEach(s => { if (!r.result.objectStoreNames.contains(s)) r.result.createObjectStore(s, { keyPath:'id' }); }); }; r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); }
function idbDo(store, mode, fn){ return new Promise((res, rej) => { const tx = DB.db.transaction(store, mode), q = fn(tx.objectStore(store)); tx.oncomplete = () => res(q && q.result); tx.onerror = () => rej(tx.error); tx.onabort = () => rej(tx.error); }); }
async function put(store, obj){
  const list = ST.db[store], i = list.findIndex(x => x.id === obj.id); if (i >= 0) list[i] = obj; else list.unshift(obj);
  if (DB.db){ try { await idbDo(store, 'readwrite', s => s.put(obj)); } catch (e) { DB.mem = true; toast('Could not store on this device. It stays until the page closes. Save a file to keep it.'); } }
}
async function del(store, id){
  ST.db[store] = ST.db[store].filter(x => x.id !== id);
  if (DB.db){ try { await idbDo(store, 'readwrite', s => s.delete(id)); } catch (e) {} }
}
async function initDb(){
  try {
    DB.db = await idbOpen();
    for (const s of ['rhythms', 'kits', 'projects']){ ST.db[s] = (await idbDo(s, 'readonly', st => st.getAll())) || []; ST.db[s].sort((a, b) => (b.updated || b.created || 0) - (a.updated || a.created || 0)); }
  } catch (e) { DB.db = null; DB.mem = true; }
  refreshSelects(); renderLib();
}

/* ---------- downloads ---------- */
let DL = null;
const STANDALONE = !(window.claude && window.claude.use) && window.top === window.self;
(async function initDl(){
  for (let i = 0; i < 20 && !(window.claude && window.claude.use); i++) await new Promise(r => setTimeout(r, 250));
  try { DL = window.claude && window.claude.use ? await window.claude.use('downloads') : null; } catch (e) { DL = null; }
  renderLib(); updateExportHint();
})();
function plainDownload(filename, blob){
  try { const a = document.createElement('a'), url = URL.createObjectURL(blob); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 60000); return true; } catch (e) { return false; }
}
/* One file: as itself where allowed. Several (or WAV/MIDI inside Claude): one .zip. */
async function giveFiles(zipName, files){
  const one = files.length === 1, allowedHere = one && /\.(json|zip)$/i.test(files[0].name);
  const name = one && (allowedHere || (!DL && STANDALONE)) ? files[0].name : zipName;
  const blob = one && name === files[0].name ? new Blob([files[0].data]) : new Blob(zipParts(files), { type:'application/zip' });
  if (!DL && STANDALONE){ if (plainDownload(name, blob)) return true; toast('The browser blocked the download.'); return false; }
  if (!DL){ toast('Saving files works in the Claude app, on claude.ai, or in the version you run on your Mac.'); return false; }
  try { await DL.save({ filename:name, data:blob }); return true; }
  catch (e) {
    const c = e && e.code;
    if (c === 'declined') return false;
    toast(c === 'rate_limited' ? 'Another save is still open. Try again in a moment.' : c === 'too_large' ? 'The file is too large to save here. Try a shorter beat.' : 'Could not save the file.');
    return false;
  }
}
function updateExportHint(){
  const h = $('#exHint'); if (!h) return;
  h.textContent = (STANDALONE && !DL ? 'Several files come as one .zip. On a Mac it opens by itself; drag the WAV and MIDI into Ableton.' : 'The WAV (24-bit) and MIDI come together in one .zip. On iPhone, tap it in Files to unpack, or AirDrop it to the Mac.') +
    ' MIDI uses General MIDI drum notes (kick C1, snare D1, hat F#1, open hat A#1, other D#1, layer kick B0) at 960 ticks per beat, so the groove stays as it is. Separate tracks are kick, snare, hats, other and layer kick. They have no glue, so they add up to the clean mix.';
}

/* ---------- views ---------- */
function go(v){
  ST.view = v;
  $$('.steps button').forEach(b => b.setAttribute('aria-selected', b.dataset.v === v ? 'true' : 'false'));
  $$('.view').forEach(s => { s.hidden = s.id !== 'v-' + v; });
  const btn = $('.steps button[data-v="' + v + '"]'); if (btn && btn.scrollIntoView) try { btn.scrollIntoView({ block:'nearest', inline:'nearest' }); } catch (e) {}
  window.scrollTo({ top:0 });
  if (v === 'loop') drawLoopWave();
  if (v === 'rhythm') renderRhythm();
  if (v === 'sounds') renderSounds();
  if (v === 'combine') renderCombine();
  if (v === 'beat') renderBeat();
  if (v === 'lib') renderLib();
}
function markDone(k){ ST.done[k] = true; $$('.steps button').forEach(b => b.classList.toggle('done', !!ST.done[b.dataset.v])); }
$$('.steps button').forEach(b => b.onclick = () => go(b.dataset.v));
document.addEventListener('click', e => { const g = e.target.closest('[data-go]'); if (g) go(g.dataset.go); });
function segSet(sel, v){ $$(sel + ' button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v) === String(v) ? 'true' : 'false')); }
function laneSeg(el, onPick){
  el.innerHTML = LANES.map(l => '<button data-v="' + l + '" style="--h:var(--h-' + l + ')">' + LANE_NAME[l] + '</button>').join('');
  el.querySelectorAll('button').forEach(b => b.onclick = () => onPick(b.dataset.v));
}
function legendHtml(withGhost){
  return LANES.map(l => '<span><i style="--h:var(--h-' + l + ')"></i>' + LANE_NAME[l] + '</span>').join('') + (withGhost ? '<span><i class="ring"></i>Ghost note</span>' : '');
}

/* ================= 1 LOOP ================= */
$('#fileLoop').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  wake(); stopPlay();
  try {
    await busy('Reading the loop…', async () => {
      const buf = await decode(await f.arrayBuffer());
      if (buf.duration > 120) throw { code:'long' };
      setLoop({ name:f.name.replace(/\.[^.]+$/, ''), ch:chansOf(buf), sr:buf.sampleRate });
    });
  } catch (err) {
    toast(err && err.code === 'long' ? 'That file is over 2 minutes. Cut out one to eight bars first.' : 'Could not read that file. Try WAV, AIFF, MP3 or M4A.');
  }
};
$('#exampleBtn').onclick = async () => {
  wake(); stopPlay();
  await busy('Making the example…', async () => { const ex = exampleLoop(SR()); setLoop({ name:ex.name, ch:ex.ch, sr:ex.sr, bpm:ex.bpm, bars:ex.bars }); });
};
function setLoop(L){
  const dur = L.ch[0].length / L.sr;
  ST.loop = { name:L.name, ch:L.ch, sr:L.sr, dur, sens:50, startMs:0, mono:toMono(L.ch) };
  ST.loop.env = envelope(ST.loop.mono, L.sr, 25); LW.key = '';
  ST.loop.onsets = analyzeLoop(L.ch, L.sr, { sens:0.5 });
  const first = ST.loop.onsets[0];
  if (first && first.t > 0.03) ST.loop.startMs = Math.round(first.t * 1000);
  const g = L.bpm ? { bpm:L.bpm, bars:L.bars } : guessTempo(dur - ST.loop.startMs / 1000, ST.loop.onsets.map(o => ({ t:o.t - ST.loop.startMs / 1000 })));
  ST.loop.bpm = g.bpm; ST.loop.bars = g.bars;
  ST.slices = suggestSlices(L.ch, L.sr, ST.loop.onsets); ST.ss = 0;
  ST.rhEdited = false; buildRhythm(true);
  $('#slKitName').value = clean(L.name) + ' kit';
  markDone('loop');
  renderLoop();
}
function reanalyze(){
  const L = ST.loop; L.onsets = analyzeLoop(L.ch, L.sr, { sens:L.sens / 100 });
  ST.slices = suggestSlices(L.ch, L.sr, L.onsets); ST.ss = 0;
  buildRhythm(); renderLoop();
}
function buildRhythm(fresh){
  const L = ST.loop; if (!L) return;
  const had = ST.rhEdited && !fresh;
  ST.rhFromLib = false;
  ST.rh = { id:null, name:clean(L.name), bpm:L.bpm, bars:L.bars, created:Date.now(), hits:rhythmFromOnsets(L.onsets, L.bpm, L.bars, L.startMs / 1000) };
  ST.rhEdited = false; ST.sel = null; ST.cb.rhId = 'work';
  if (had) toast('The rhythm was rebuilt from the loop. Your edits to it were replaced.');
  if (!ST.gTouchedBpm) ST.g.bpm = Math.round(L.bpm * 2) / 2;
  refreshSelects();
}
function renderLoop(){
  const L = ST.loop; $('#loopCard').hidden = !L; if (!L) return;
  $('#loopName').textContent = L.name;
  const counts = {}; L.onsets.forEach(o => o.labels.forEach(l => counts[l] = (counts[l] || 0) + 1));
  $('#loopMeta').textContent = L.dur.toFixed(2) + ' s · ' + L.onsets.length + ' hits · ' + LANES.filter(l => counts[l]).map(l => counts[l] + ' ' + LANE_NAME[l].toLowerCase()).join(', ');
  $('#bpmIn').value = L.bpm; segSet('#barsSeg', L.bars); $('#startIn').value = L.startMs;
  $('#sens').value = L.sens; $('#sensOut').textContent = L.sens + '%';
  $('#loopLegend').innerHTML = legendHtml(false);
  drawLoopWave();
}
const LW = { key:'', img:null };
function drawLoopWave(){
  const L = ST.loop, cv = $('#loopWave'); if (!L || ST.view !== 'loop' || !cv.parentElement.clientWidth) return;
  const box = cv.parentElement, w = box.clientWidth, h = box.clientHeight, d = window.devicePixelRatio || 1;
  const key = [w, h, d, L.bpm, L.bars, L.startMs, L.onsets.length, L.sens, css('--wave'), L.name].join('|');
  if (key !== LW.key){
    const off = document.createElement('canvas'); off.width = Math.round(w * d); off.height = Math.round(h * d);
    const g = off.getContext('2d'); g.setTransform(d, 0, 0, d, 0, 0);
    const spb = 60 / L.bpm, s0 = L.startMs / 1000, xs = t => t / L.dur * w;
    g.fillStyle = css('--grid');
    for (let b = 0; b <= L.bars * 4; b++){ const t = s0 + b * spb; if (t > L.dur) break; g.fillRect(Math.round(xs(t)), 0, b % 4 ? 1 : 2, h); }
    drawWave(g, L.mono, 0, L.mono.length, w, h, css('--wave'));
    L.onsets.forEach(o => { o.labels.forEach((l, k) => { g.fillStyle = laneCol(l); g.fillRect(Math.round(xs(o.t)) - 1, h - 10 - k * 9, 3, 8); }); });
    LW.key = key; LW.img = off;
  }
  const g = fit(cv, w, h); g.clearRect(0, 0, w, h); g.drawImage(LW.img, 0, 0, w, h);
  if (PL.kind === 'loop' || PL.kind === 'orig'){ const t = playPos(); g.fillStyle = css('--ink'); g.fillRect(Math.round(t / L.dur * w), 0, 2, h); }
}
$('#loopWaveBox').onclick = e => {
  const L = ST.loop; if (!L) return;
  const r = e.currentTarget.getBoundingClientRect(), t = (e.clientX - r.left) / r.width * L.dur;
  playBuf(L.ch, L.sr, { loop:true, from:t, label:L.name, kind:'loop', bpm:0 });
};
$('#playLoop').onclick = () => { if (PL.kind === 'loop') return stopPlay(); const L = ST.loop; if (L) playBuf(L.ch, L.sr, { loop:true, label:L.name, kind:'loop' }); };
const setBpm = v => { const L = ST.loop; if (!L || !isFinite(v)) return; L.bpm = clamp(Math.round(v * 100) / 100, 40, 220); ST.gTouchedBpm = false; buildRhythm(); renderLoop(); };
$('#bpmIn').onchange = e => setBpm(parseFloat(e.target.value));
$('#bpmDown').onclick = () => setBpm(Math.round(ST.loop.bpm) - 1);
$('#bpmUp').onclick = () => setBpm(Math.round(ST.loop.bpm) + 1);
$$('#barsSeg button').forEach(b => b.onclick = () => {
  const L = ST.loop, nb = +b.dataset.v, ratio = nb / L.bars;
  L.bars = nb; L.bpm = clamp(Math.round(L.bpm * ratio * 100) / 100, 40, 220);   // same loop length, more bars = faster
  buildRhythm(); renderLoop();
});
const setStart = v => { const L = ST.loop; if (!L || !isFinite(v)) return; L.startMs = clamp(Math.round(v), -500, Math.round(L.dur * 1000) - 50); buildRhythm(); renderLoop(); };
$('#startIn').onchange = e => setStart(parseFloat(e.target.value));
$('#startDown').onclick = () => setStart(ST.loop.startMs - 2);
$('#startUp').onclick = () => setStart(ST.loop.startMs + 2);
let sensT = 0;
$('#sens').oninput = e => { $('#sensOut').textContent = e.target.value + '%'; clearTimeout(sensT); sensT = setTimeout(() => { ST.loop.sens = +e.target.value; reanalyze(); }, 250); };
$('#goRhythm').onclick = () => go('rhythm');
$('#goSounds').onclick = () => go('sounds');

/* ================= 2 RHYTHM ================= */
const RG = { colW:26, top:20, rowH:34 };
function rhStats(r){
  const G = grooveOf(r), late = ['kick', 'snare'].filter(l => G.lateMs[l] != null).map(l => LANE_NAME[l].toLowerCase() + ' ' + fmtMs(G.lateMs[l]));
  return r.bpm + ' BPM · ' + r.bars + (r.bars === 1 ? ' bar · ' : ' bars · ') + r.hits.length + ' hits · swing ' + Math.round(G.swing) + '%' + (late.length ? ' · ' + late.join(', ') : '');
}
function renderRhythm(){
  const r = ST.rh; $('#rhEmpty').hidden = !!r; $('#rhCard').hidden = !r; if (!r) return;
  $('#rhName').value = r.name; $('#rhMeta').textContent = rhStats(r);
  $('#rhLegend').innerHTML = legendHtml(true);
  $('#rhPlayOrig').hidden = !ST.loop || ST.rhFromLib;
  drawGrid($('#rhGrid'), $('#rhWrap'), r, ST.sel, PL.kind === 'rhkit' || PL.kind === 'orig');
  renderHitPanel();
}
function gridGeom(wrap, r){ const cols = r.bars * 16, w = wrap.clientWidth - 2; const colW = Math.max(24, Math.floor(w / cols)); return { cols, colW, W:cols * colW, H:RG.top + LANES.length * RG.rowH + 6 }; }
function drawGrid(cv, wrap, r, sel, showHead, layer){
  if (!wrap.clientWidth) return;
  const G = gridGeom(wrap, r), g = fit(cv, G.W, G.H), cw = G.colW;
  g.clearRect(0, 0, G.W, G.H);
  LANES.forEach((l, i) => { if (i % 2){ g.fillStyle = css('--grid'); g.globalAlpha = 0.35; g.fillRect(0, RG.top + i * RG.rowH, G.W, RG.rowH); g.globalAlpha = 1; } });
  for (let s = 0; s < G.cols; s++){
    const x = s * cw + cw / 2;
    g.fillStyle = s % 16 === 0 ? css('--ink') : s % 4 === 0 ? css('--grid-2') : css('--grid');
    g.fillRect(Math.round(x), RG.top - 4, s % 16 === 0 ? 2 : 1, G.H - RG.top);
    if (s % 4 === 0){ g.fillStyle = css('--muted'); g.font = '500 11px ' + css('--f-mono'); g.fillText(s % 16 === 0 ? String(s / 16 + 1) : (s / 16 | 0) + 1 + '.' + ((s % 16) / 4 + 1), x + 3, 13); }
  }
  const spb = 60 / r.bpm;
  r.hits.forEach(h => {
    const li = LANES.indexOf(h.lane), x = (h.pos * 4) * cw + cw / 2, y = RG.top + li * RG.rowH + RG.rowH / 2, rad = 4 + 8 * h.vel;
    const ghost = h.lane === 'snare' && h.vel < 0.45;
    g.beginPath(); g.arc(x, y, rad, 0, Math.PI * 2);
    if (ghost){ g.lineWidth = 2.5; g.strokeStyle = laneCol(h.lane); g.stroke(); }
    else { g.fillStyle = laneCol(h.lane); g.fill(); }
    if (layer && layerWanted({ ...h, pos:h.pos }, layer)){ g.beginPath(); g.arc(x, y, rad + 4, 0, Math.PI * 2); g.lineWidth = 2; g.strokeStyle = laneCol('layer'); g.stroke(); }
    if (sel && sel === h.id){ g.beginPath(); g.arc(x, y, rad + 5, 0, Math.PI * 2); g.lineWidth = 2; g.strokeStyle = css('--ink'); g.stroke(); }
  });
  if (showHead && PL.src && PL.bpm){
    const beats = (playPos() / (60 / PL.bpm)) % (r.bars * 4), x = beats * 4 * cw + cw / 2;
    g.fillStyle = css('--ink'); g.fillRect(Math.round(x), RG.top - 4, 2, G.H - RG.top);
  }
  cv._geom = G;
}
$('#rhGrid').addEventListener('click', e => {
  const r = ST.rh, cv = e.currentTarget, G = cv._geom; if (!r || !G) return;
  const rc = cv.getBoundingClientRect(), x = e.clientX - rc.left, y = e.clientY - rc.top, li = Math.floor((y - RG.top) / RG.rowH);
  if (li < 0 || li >= LANES.length) return;
  const lane = LANES[li];
  let best = null, bd = Math.max(13, G.colW * 0.55);
  r.hits.forEach(h => { if (h.lane !== lane) return; const d = Math.abs(h.pos * 4 * G.colW + G.colW / 2 - x); if (d < bd){ bd = d; best = h; } });
  if (best){ ST.sel = best.id; auditionHit(best); }
  else {
    const slot = clamp(Math.round((x - G.colW / 2) / G.colW), 0, r.bars * 16 - 1), Gr = grooveOf(r);
    const same = r.hits.filter(h => h.lane === lane), vel = lane === 'snare' ? 0.3 : same.length ? same.reduce((s, h) => s + h.vel, 0) / same.length : 0.8;
    const h = { id:'n' + uid(), lane, vel:Math.round(vel * 100) / 100, pos:Math.max(0, slot / 4 + Gr.off(lane, slot % 4)), src:null };
    r.hits.push(h); r.hits.sort((a, b) => a.pos - b.pos); ST.sel = h.id; ST.rhEdited = true; auditionHit(h);
  }
  renderRhythm();
});
function selHit(){ return ST.rh && ST.rh.hits.find(h => h.id === ST.sel); }
laneSeg($('#hitLane'), l => { const h = selHit(); if (!h) return; h.lane = l; ST.rhEdited = true; renderRhythm(); auditionHit(h); });
function renderHitPanel(){
  const h = selHit(), p = $('#hitPanel'); p.hidden = !h; if (!h) return;
  const r = ST.rh, q = Math.round(h.pos * 4), bar = Math.floor(q / 16) + 1, beat = Math.floor((q % 16) / 4) + 1, six = q % 4 + 1;
  $('#hitTitle').textContent = LANE_NAME[h.lane] + ' · bar ' + bar + ', beat ' + beat + (six > 1 ? ', 16th ' + six : '');
  segSet('#hitLane', h.lane);
  $('#hitVel').value = Math.round(h.vel * 100); $('#hitVelOut').textContent = Math.round(h.vel * 100) + (h.lane === 'snare' && h.vel < 0.45 ? ' · ghost' : '');
  $('#hitOff').textContent = fmtMs((h.pos - q / 4) * 60 / r.bpm * 1000) + ' from grid';
}
$('#hitVel').oninput = e => { const h = selHit(); if (!h) return; h.vel = +e.target.value / 100; ST.rhEdited = true; renderRhythm(); };
const nudge = ms => { const h = selHit(); if (!h) return; h.pos = Math.max(0, h.pos + ms / 1000 / (60 / ST.rh.bpm)); ST.rh.hits.sort((a, b) => a.pos - b.pos); ST.rhEdited = true; renderRhythm(); };
$('#hitEarly').onclick = () => nudge(-2);
$('#hitLate').onclick = () => nudge(2);
$('#hitSnap').onclick = () => { const h = selHit(); if (!h) return; h.pos = Math.round(h.pos * 4) / 4; ST.rhEdited = true; renderRhythm(); };
$('#hitDel').onclick = () => { const r = ST.rh, h = selHit(); if (!h) return; r.hits.splice(r.hits.indexOf(h), 1); ST.sel = null; ST.rhEdited = true; renderRhythm(); };
$('#hitPlay').onclick = () => { const h = selHit(); if (h) auditionHit(h); };
$('#rhName').oninput = e => { if (ST.rh) ST.rh.name = e.target.value; };
function auditionHit(h){
  const L = ST.loop;
  if (L && h.src != null && !ST.rhFromLib && ST.slices[h.src]){ const s = ST.slices[h.src]; shot(L.ch.map(c => c.subarray(s.start, s.end)), L.sr); return; }
  const k = kitById($('#rhKit').value) || builtin(), arr = (k.lanes[h.lane] && k.lanes[h.lane].length ? k.lanes[h.lane] : builtin().lanes[h.lane]);
  const s = arr[0]; shot(soundAt(s, SR()), SR(), velGain(h.vel) * dbToGain(s.gain || 0));
}
function loopify(out, beats, bpm, sr){
  const n = Math.round(beats * 60 / bpm * sr), L = out.L.slice(0, n), R = out.R.slice(0, n);
  for (let i = n; i < out.n; i++){ L[(i - n) % n] += out.L[i]; R[(i - n) % n] += out.R[i]; }
  return { L, R };
}
function previewRhythm(r, kit, layer, kind, label){
  const sr = SR(), seq = loopEvents(r, 1), out = renderEvents(seq, kit, { sr, bpm:r.bpm, fallback:ST.cb.fallback || kit.builtin ? builtin() : null, layer });
  const lp = loopify(out, seq.beats, r.bpm, sr); master(lp.L, lp.R, 0);
  playBuf([lp.L, lp.R], sr, { loop:true, label, kind, bpm:r.bpm });
}
$('#rhPlayKit').onclick = () => {
  if (PL.kind === 'rhkit') return stopPlay();
  const r = ST.rh; if (!r) return; const k = kitById($('#rhKit').value) || builtin();
  previewRhythm(r, k, null, 'rhkit', r.name + ' with ' + k.name);
};
$('#rhPlayOrig').onclick = () => { if (PL.kind === 'orig') return stopPlay(); const L = ST.loop; if (L) playBuf(L.ch, L.sr, { loop:true, label:L.name, kind:'orig', bpm:L.bpm, from:Math.max(0, L.startMs / 1000) }); };
$('#rhSave').onclick = async () => {
  const r = ST.rh; if (!r) return;
  r.name = clean($('#rhName').value) || r.name || 'Rhythm';
  if (!r.id) r.id = 'r' + uid();
  const copy = deepRh(r); copy.updated = Date.now();
  await put('rhythms', copy); ST.cb.rhId = r.id; ST.rhEdited = false;
  refreshSelects(); markDone('rhythm');
  $('#rhSaved').textContent = 'Saved “' + r.name + '” in the Library. Saving again updates it.';
};
$('#rhMidi').onclick = () => { const r = ST.rh; if (!r) return; const nm = fileBase(r.name); giveFiles(nm + ' rhythm.zip', [{ name:nm + ' rhythm.mid', data:encodeMidi(loopEvents(r, 1), r.bpm, r.name) }]); };
$('#rhToCombine').onclick = () => { ST.cb.rhId = ST.rh && ST.rh.id && !ST.rhEdited ? ST.rh.id : 'work'; go('combine'); };

/* ================= 3 SOUNDS ================= */
const SZ = { a:0, b:1, drag:null };
function sel(){ return ST.slices[ST.ss]; }
function renderSounds(){
  const L = ST.loop; $('#slEmpty').hidden = !!L; $('#slCard').hidden = !L; if (!L) return;
  const kept = ST.slices.filter(s => s.keep).length;
  $('#slMeta').textContent = ST.slices.length + ' hits · ' + kept + ' kept';
  $('#slPads').innerHTML = ST.slices.map((s, i) => {
    const f = sliceFlags(s, L.onsets, L.env, L.sr), st = !f.length ? 'Clean' : f[0].k === 'overlap' ? 'Overlap' : f[0].k === 'bleed' ? 'Bleed' : f[0].k === 'more' ? 'Runs on' : 'Cut short';
    return '<button class="pad' + (s.keep ? ' keep' : '') + (i === ST.ss ? ' sel' : '') + (s.keep || i === ST.ss ? '' : ' dim') + '" data-i="' + i + '" style="--h:var(--h-' + s.lane + ')"><span class="n">' + (i + 1) + '</span><span>' + LANE_NAME[s.lane] + '</span><span>' + Math.round((s.end - s.start) / L.sr * 1000) + ' ms</span><span class="st">' + st + '</span><span class="kp" aria-hidden="true">' + (s.keep ? '✓' : '') + '</span></button>';
  }).join('');
  $$('#slPads .pad').forEach(p => p.onclick = () => { ST.ss = +p.dataset.i; playSlice(); renderSounds(); });
  renderSlicePanel(); drawSlWave(); drawZoom();
  const sv = $('#slKitSel').value; $('#slKitNameF').hidden = sv !== 'new';
  $('#slSave').textContent = kept ? 'Save ' + kept + (kept === 1 ? ' sound' : ' sounds') : 'Mark sounds with “Keep” first';
  $('#slSave').disabled = !kept;
}
function renderSlicePanel(){
  const L = ST.loop, s = sel(); if (!s) return;
  $('#slTitle').textContent = '#' + (ST.ss + 1) + ' · ' + LANE_NAME[s.lane] + ' · ' + Math.round((s.end - s.start) / L.sr * 1000) + ' ms';
  const f = sliceFlags(s, L.onsets, L.env, L.sr);
  $('#slFlags').innerHTML = f.length ? f.map(x => '<li>' + esc(x.t) + '</li>').join('') : '<li class="ok">Clean: one drum, the tail fades out on its own.</li>';
  segSet('#slLane', s.lane);
  $('#slKeep').setAttribute('aria-pressed', s.keep ? 'true' : 'false'); $('#slKeep').textContent = s.keep ? 'Kept for the kit' : 'Keep for the kit';
  $('#slFi').value = Math.round(s.fadeIn * 10); $('#slFiOut').textContent = s.fadeIn.toFixed(1) + ' ms';
  $('#slFo').value = s.fadeOut; $('#slFoOut').textContent = s.fadeOut + ' ms';
  $('#slGain').value = s.gain; $('#slGainOut').textContent = fmtDb(s.gain);
}
function drawSlWave(){
  const L = ST.loop, cv = $('#slWave'); if (!L || !cv.parentElement.clientWidth) return;
  const { x:g, w, h } = boxFit(cv), n = L.mono.length, xs = i => i / n * w;
  g.clearRect(0, 0, w, h);
  ST.slices.forEach((s, i) => { g.fillStyle = laneCol(s.lane, i === ST.ss ? 0.5 : s.keep ? 0.3 : 0.12); g.fillRect(xs(s.start), 0, Math.max(2, xs(s.end) - xs(s.start)), h); });
  drawWave(g, L.mono, 0, n, w, h, css('--wave'));
  ST.slices.forEach((s, i) => { g.fillStyle = i === ST.ss ? css('--ink') : laneCol(s.lane); g.fillRect(Math.round(xs(s.start)), 0, i === ST.ss ? 2 : 1, h); });
}
$('#slWaveBox').onclick = e => {
  const L = ST.loop; if (!L) return; const r = e.currentTarget.getBoundingClientRect(), at = (e.clientX - r.left) / r.width * L.mono.length;
  let k = 0; ST.slices.forEach((s, i) => { if (s.start <= at) k = i; });
  ST.ss = k; playSlice(); renderSounds();
};
function zoomRange(){ const L = ST.loop, s = sel(), pre = Math.round(0.025 * L.sr); const a = Math.max(0, s.start - pre), b = Math.min(L.mono.length, Math.max(s.end, Math.min(s.natEnd, s.start + Math.round(1.2 * L.sr))) + Math.round(0.05 * L.sr)); return [a, Math.max(b, a + Math.round(0.08 * L.sr))]; }
function drawZoom(){
  const L = ST.loop, s = sel(), cv = $('#slZoom'); if (!L || !s || !cv.parentElement.clientWidth) return;
  const { x:g, w, h } = boxFit(cv), [a, b] = zoomRange(); SZ.a = a; SZ.b = b; SZ.w = w;
  const xs = i => (i - a) / (b - a) * w;
  g.clearRect(0, 0, w, h);
  drawWave(g, L.mono, a, b, w, h, css('--wave'));
  g.fillStyle = css('--wave-bg'); g.globalAlpha = 0.72; g.fillRect(0, 0, xs(s.start), h); g.fillRect(xs(s.end), 0, w - xs(s.end), h); g.globalAlpha = 1;
  L.onsets.forEach(o => { if (o.at > a && o.at < b){ g.fillStyle = laneCol(o.labels[0]); g.fillRect(Math.round(xs(o.at)), h - 12, 3, 10); } });
  // fades
  g.strokeStyle = css('--ink'); g.lineWidth = 1.5; g.beginPath();
  const fi = s.fadeIn / 1000 * L.sr, fo = s.fadeOut / 1000 * L.sr;
  g.moveTo(xs(s.start), h - 2); g.lineTo(xs(s.start + fi), 4); g.lineTo(xs(s.end - fo), 4); g.lineTo(xs(s.end), h - 2); g.stroke();
  [s.start, s.end].forEach(p => { const x = Math.round(xs(p)); g.fillStyle = css('--accent'); g.fillRect(x - 1.5, 0, 3, h); g.beginPath(); g.arc(x, 14, 9, 0, Math.PI * 2); g.fill(); g.strokeStyle = css('--accent-ink'); g.lineWidth = 1.5; g.stroke(); });
  g.fillStyle = css('--muted'); g.font = '500 11px ' + css('--f-mono'); g.fillText(Math.round((b - a) / L.sr * 1000) + ' ms shown', 8, h - 6);
}
(function zoomDrag(){
  const box = $('#slZoomBox');
  const toSample = e => { const r = box.getBoundingClientRect(); return SZ.a + (e.clientX - r.left) / r.width * (SZ.b - SZ.a); };
  box.addEventListener('pointerdown', e => {
    const s = sel(); if (!s) return; const r = box.getBoundingClientRect(), x = e.clientX - r.left;
    const xs = i => (i - SZ.a) / (SZ.b - SZ.a) * r.width, ds = Math.abs(xs(s.start) - x), de = Math.abs(xs(s.end) - x);
    SZ.drag = ds <= de ? 'start' : 'end'; if (Math.min(ds, de) > 44){ SZ.drag = null; playSlice(); return; }
    box.setPointerCapture(e.pointerId); e.preventDefault();
  });
  box.addEventListener('pointermove', e => {
    if (!SZ.drag) return; const L = ST.loop, s = sel(), p = Math.round(toSample(e)), minLen = Math.round(0.006 * L.sr);
    if (SZ.drag === 'start') s.start = clamp(p, 0, s.end - minLen); else s.end = clamp(p, s.start + minLen, L.mono.length);
    s.natEnd = Math.max(s.natEnd, s.end); drawZoom(); drawSlWave();
  });
  const up = () => { if (!SZ.drag) return; SZ.drag = null; renderSounds(); playSlice(); };
  box.addEventListener('pointerup', up); box.addEventListener('pointercancel', up);
})();
function playSlice(){ const L = ST.loop, s = sel(); if (!L || !s) return; shot(extractSlice(L.ch, L.sr, s), L.sr); }
$('#slPlay').onclick = playSlice;
laneSeg($('#slLane'), l => { const s = sel(); if (s){ s.lane = l; renderSounds(); } });
$('#slKeep').onclick = () => { const s = sel(); if (s){ s.keep = !s.keep; renderSounds(); } };
$('#slFi').oninput = e => { const s = sel(); s.fadeIn = +e.target.value / 10; renderSlicePanel(); drawZoom(); };
$('#slFo').oninput = e => { const s = sel(); s.fadeOut = +e.target.value; renderSlicePanel(); drawZoom(); };
$('#slGain').oninput = e => { const s = sel(); s.gain = +e.target.value; renderSlicePanel(); };
[['#slFi', 0], ['#slFo', 0], ['#slGain', 0]].forEach(([q]) => $(q).addEventListener('change', playSlice));
const moveCut = (k, ms) => { const L = ST.loop, s = sel(), d = Math.round(ms / 1000 * L.sr), minLen = Math.round(0.006 * L.sr); if (k === 'start') s.start = clamp(s.start + d, 0, s.end - minLen); else { s.end = clamp(s.end + d, s.start + minLen, L.mono.length); s.natEnd = Math.max(s.natEnd, s.end); } renderSounds(); playSlice(); };
$('#slS1').onclick = () => moveCut('start', -1); $('#slS2').onclick = () => moveCut('start', 1);
$('#slE1').onclick = () => moveCut('end', -10); $('#slE2').onclick = () => moveCut('end', 10);
$('#slReset').onclick = () => { const L = ST.loop, fresh = suggestSlices(L.ch, L.sr, L.onsets)[ST.ss]; const s = sel(); Object.assign(s, { start:fresh.start, end:fresh.end, natEnd:fresh.natEnd, fadeIn:fresh.fadeIn, fadeOut:fresh.fadeOut, gain:0, lane:fresh.lane }); renderSounds(); playSlice(); };
$('#slAuto').onclick = () => {
  const L = ST.loop; if (!L) return; let n = 0;
  LANES.forEach(l => {
    const c = ST.slices.filter(s => s.lane === l); if (!c.length) return;
    const score = s => { const f = sliceFlags(s, L.onsets, L.env, L.sr); const o = L.onsets[s.on]; return -f.length * 2 + (o ? (o.vel[l] || 0) : 0); };
    c.sort((a, b) => score(b) - score(a)); if (!c[0].keep){ c[0].keep = true; n++; }
  });
  renderSounds(); toast(n ? 'Kept ' + n + ' more. Listen to each and change what you like.' : 'The best ones are already kept.');
};
$('#slKitSel').onchange = () => renderSounds();
$('#slSave').onclick = async () => {
  const L = ST.loop; if (!L) return;
  const kept = ST.slices.map((s, i) => ({ s, i })).filter(x => x.s.keep); if (!kept.length) return;
  let kit, v = $('#slKitSel').value;
  if (v === 'new'){ kit = { id:'k' + uid(), name:clean($('#slKitName').value) || clean(L.name) + ' kit', created:Date.now(), lanes:Object.fromEntries(LANES.map(l => [l, []])) }; }
  else { kit = kitById(v); if (!kit) return; }
  kept.forEach(({ s, i }) => {
    const arr = kit.lanes[s.lane] || (kit.lanes[s.lane] = []);
    arr.push({ id:'s' + uid(), name:clean(L.name) + ' ' + LANE_NAME[s.lane].toLowerCase() + ' #' + (i + 1), sr:L.sr, ch:extractSlice(L.ch, L.sr, s), gain:0, from:L.name });
    if (arr.length > 8) arr.shift();
  });
  kit.updated = Date.now();
  await put('kits', kit); ST.cb.kitId = kit.id; refreshSelects(); $('#slKitSel').value = kit.id;
  markDone('sounds');
  ST.slices.forEach(s => s.keep = false); renderSounds();
  $('#slSaved').textContent = 'Saved ' + kept.length + ' sounds in “' + kit.name + '”. It is now the kit in Combine.';
};

/* ================= 4 COMBINE ================= */
const projDefault = (r, k) => !r ? '' : k.builtin || k.name.startsWith(r.name) ? r.name + ' beat' : r.name + ' + ' + k.name;
function kitById(id){ if (id === 'builtin') return builtin(); return ST.db.kits.find(k => k.id === id) || null; }
function cbRhythm(){ if (ST.cb.rhId === 'work') return ST.rh; return ST.db.rhythms.find(r => r.id === ST.cb.rhId) || ST.rh; }
function cbKit(){ return kitById(ST.cb.kitId) || builtin(); }
function layerSound(id){
  builtin(); if (!id || id === HARD_KICK_ID) return HARD;
  const [kid, sid] = id.split('|'), k = kitById(kid); if (!k) return HARD;
  for (const l of LANES) for (const s of (k.lanes[l] || [])) if (s.id === sid) return s;
  return HARD;
}
function layerCfg(){ const y = ST.cb.layer; return y.on ? { ...y, sound:layerSound(y.src), picked:y.picked.slice() } : null; }
function refreshSelects(){
  const kits = ST.db.kits, ko = '<option value="builtin">Basic synth kit (built in)</option>' + kits.map(k => '<option value="' + esc(k.id) + '">' + esc(k.name) + '</option>').join('');
  $('#rhKit').innerHTML = ko; $('#rhKit').value = kitById(ST.cb.kitId) ? ST.cb.kitId : 'builtin';
  $('#cbKit').innerHTML = ko + '<option value="__new">+ New empty kit</option>'; $('#cbKit').value = kitById(ST.cb.kitId) ? ST.cb.kitId : 'builtin';
  const sv = $('#slKitSel').value; $('#slKitSel').innerHTML = '<option value="new">New kit</option>' + kits.map(k => '<option value="' + esc(k.id) + '">Add to “' + esc(k.name) + '”</option>').join('');
  $('#slKitSel').value = sv && (sv === 'new' || kitById(sv)) ? sv : 'new';
  const rhs = ST.db.rhythms, cur = ST.rh && (!ST.rh.id || ST.rhEdited || !rhs.some(r => r.id === ST.rh.id)) ? '<option value="work">' + esc(ST.rh.name || 'Rhythm') + ' (not saved)</option>' : '';
  $('#cbRh').innerHTML = cur + rhs.map(r => '<option value="' + esc(r.id) + '">' + esc(r.name) + ' · ' + r.bpm + ' BPM</option>').join('');
  if (ST.cb.rhId === 'work' && !cur && ST.rh && ST.rh.id) ST.cb.rhId = ST.rh.id;
  if (!$('#cbRh').querySelector('option[value="' + CSS.escape(ST.cb.rhId) + '"]')) ST.cb.rhId = $('#cbRh').options[0] ? $('#cbRh').options[0].value : 'work';
  $('#cbRh').value = ST.cb.rhId;
  let lo = '<option value="' + HARD_KICK_ID + '">Built-in hard kick</option>';
  kits.forEach(k => (k.lanes.kick || []).forEach(s => { lo += '<option value="' + esc(k.id + '|' + s.id) + '">' + esc(k.name + ' · ' + s.name) + '</option>'; }));
  $('#lySrc').innerHTML = lo; $('#lySrc').value = ST.cb.layer.src; if ($('#lySrc').value !== ST.cb.layer.src){ ST.cb.layer.src = HARD_KICK_ID; $('#lySrc').value = HARD_KICK_ID; }
}
function renderCombine(){
  refreshSelects();
  const r = cbRhythm(), k = cbKit(), y = ST.cb.layer;
  if (r){ drawGrid($('#cbGrid'), $('#cbWrap'), r, null, PL.kind === 'combine', layerCfg()); $('#cbRhMeta').textContent = rhStats(r); }
  else { $('#cbRhMeta').textContent = 'No rhythm yet. Get one from a loop in step 2.'; }
  $('#cbLanes').innerHTML = LANES.map(l => {
    const arr = k.lanes[l] || [];
    const chips = arr.map((s, i) => '<span class="chip"><button class="btn" data-a="play" data-l="' + l + '" data-i="' + i + '" aria-label="Play">▶</button><span title="' + esc(s.name) + '">' + esc(s.name) + '</span>' +
      (k.builtin ? '' : '<button class="btn" data-a="dn" data-l="' + l + '" data-i="' + i + '" aria-label="Quieter">−</button><span class="db">' + fmtDb(s.gain || 0) + '</span><button class="btn" data-a="up" data-l="' + l + '" data-i="' + i + '" aria-label="Louder">+</button><button class="btn" data-a="rm" data-l="' + l + '" data-i="' + i + '" aria-label="Remove">' + (ST.armRm === l + i ? 'Remove?' : '×') + '</button>') + '</span>').join('');
    const none = !arr.length ? '<span class="empty-lane">' + (l === 'ohat' && (k.lanes.hat || []).length ? 'Uses the hi-hat' : ST.cb.fallback ? 'Synth stand-in' : 'Silent') + '</span>' : '';
    const add = k.builtin ? '' : '<label class="btn small" style="min-height:32px">+ File<input type="file" accept="audio/*,.wav,.aif,.aiff,.mp3,.m4a" multiple data-l="' + l + '"></label>';
    return '<div class="lrow"><span class="ln" style="--h:var(--h-' + l + ')"><i></i>' + LANE_NAME[l] + '</span><div class="chips">' + chips + none + add + '</div></div>';
  }).join('') + (k.builtin ? '<p class="hint">The built-in kit is synthesized, not from a loop. Save sounds in step 3, or pick “+ New empty kit” to build one from single files.</p>' : '');
  $('#cbFallback').setAttribute('aria-pressed', ST.cb.fallback ? 'true' : 'false');
  $('#lyOn').setAttribute('aria-pressed', y.on ? 'true' : 'false'); $('#lyOn').textContent = y.on ? 'On' : 'Off';
  segSet('#lyMode', y.mode);
  $('#lyDb').value = y.db; $('#lyDbOut').textContent = fmtDb(y.db);
  $('#lyOff').value = y.offsetMs; $('#lyOffOut').textContent = fmtMs(y.offsetMs);
  $('#lyLen').value = y.lengthMs; $('#lyLenOut').textContent = y.lengthMs + ' ms';
  $('#lyVel').setAttribute('aria-pressed', y.followVel ? 'true' : 'false');
  const pk = $('#lyPicks'); pk.hidden = y.mode !== 'pick';
  if (y.mode === 'pick' && r){
    const kicks = r.hits.filter(h => h.lane === 'kick');
    pk.innerHTML = kicks.length ? kicks.map(h => { const q = Math.round(h.pos * 4); return '<button class="btn" data-id="' + esc(h.id) + '" aria-pressed="' + (y.picked.includes(h.id) ? 'true' : 'false') + '">' + (Math.floor(q / 16) + 1) + '.' + (Math.floor(q % 16 / 4) + 1) + (q % 4 ? '.' + (q % 4 + 1) : '') + '</button>'; }).join('') : '<span class="empty">This rhythm has no kicks.</span>';
    pk.querySelectorAll('button').forEach(b => b.onclick = () => { const id = b.dataset.id, i = y.picked.indexOf(id); if (i >= 0) y.picked.splice(i, 1); else y.picked.push(id); renderCombine(); });
  }
  $('#projName').value = ST.cb.projName || projDefault(r, k);
  $('#cbPlay').disabled = !r;
}
$('#cbRh').onchange = e => { ST.cb.rhId = e.target.value; const r = cbRhythm(); if (r && !ST.gTouchedBpm) ST.g.bpm = Math.round(r.bpm * 2) / 2; if (PL.kind === 'combine') stopPlay(); renderCombine(); };
$('#cbKit').onchange = async e => {
  if (e.target.value === '__new'){
    const k = { id:'k' + uid(), name:'Kit ' + (ST.db.kits.length + 1), created:Date.now(), lanes:Object.fromEntries(LANES.map(l => [l, []])) };
    await put('kits', k); ST.cb.kitId = k.id; toast('New empty kit. Add files to each drum with “+ File”. Rename it in the Library.');
  } else ST.cb.kitId = e.target.value;
  if (PL.kind === 'combine') stopPlay(); renderCombine();
};
$('#cbLanes').addEventListener('click', async e => {
  const b = e.target.closest('button[data-a]'); if (!b) return;
  const k = cbKit(), l = b.dataset.l, i = +b.dataset.i, s = k.lanes[l][i]; if (!s) return;
  if (b.dataset.a === 'play'){ shot(soundAt(s, SR()), SR(), dbToGain(s.gain || 0)); return; }
  if (b.dataset.a === 'up' || b.dataset.a === 'dn'){ s.gain = clamp((s.gain || 0) + (b.dataset.a === 'up' ? 1 : -1), -24, 12); await put('kits', k); renderCombine(); shot(soundAt(s, SR()), SR(), dbToGain(s.gain)); return; }
  if (b.dataset.a === 'rm'){
    if (ST.armRm !== l + i){ ST.armRm = l + i; renderCombine(); setTimeout(() => { if (ST.armRm === l + i){ ST.armRm = null; renderCombine(); } }, 3000); return; }
    ST.armRm = null; k.lanes[l].splice(i, 1); await put('kits', k); renderCombine();
  }
});
$('#cbLanes').addEventListener('change', async e => {
  const inp = e.target.closest('input[type=file]'); if (!inp) return;
  const k = cbKit(), l = inp.dataset.l, files = [...inp.files]; inp.value = ''; if (!files.length || k.builtin) return;
  let n = 0;
  for (const f of files){
    try { const buf = await decode(await f.arrayBuffer()); if (buf.duration > 6){ toast(f.name + ' is longer than 6 seconds, so it was skipped.'); continue; } k.lanes[l].push({ id:'s' + uid(), name:clean(f.name.replace(/\.[^.]+$/, '')), sr:buf.sampleRate, ch:trimStart(chansOf(buf)), gain:0, from:'file' }); n++; }
    catch (err) { toast('Could not read ' + f.name + '.'); }
  }
  if (n){ await put('kits', k); renderCombine(); toast('Added ' + n + (n === 1 ? ' sound to ' : ' sounds to ') + LANE_NAME[l].toLowerCase() + '.'); }
});
function trimStart(chs){ const m = toMono(chs); let i = 0; const th = 0.0015; while (i < m.length && Math.abs(m[i]) < th) i++; i = Math.max(0, i - 16); return i > 0 ? chs.map(c => c.slice(i)) : chs; }
$('#cbFallback').onclick = () => { ST.cb.fallback = !ST.cb.fallback; renderCombine(); };
$('#lyOn').onclick = () => { ST.cb.layer.on = !ST.cb.layer.on; renderCombine(); };
$('#lySrc').onchange = e => { ST.cb.layer.src = e.target.value; auditionLayer(); };
$$('#lyMode button').forEach(b => b.onclick = () => { ST.cb.layer.mode = b.dataset.v; ST.cb.layer.on = true; renderCombine(); });
$('#lyDb').oninput = e => { ST.cb.layer.db = +e.target.value; $('#lyDbOut').textContent = fmtDb(ST.cb.layer.db); };
$('#lyOff').oninput = e => { ST.cb.layer.offsetMs = +e.target.value; $('#lyOffOut').textContent = fmtMs(ST.cb.layer.offsetMs); };
$('#lyLen').oninput = e => { ST.cb.layer.lengthMs = +e.target.value; $('#lyLenOut').textContent = ST.cb.layer.lengthMs + ' ms'; };
['#lyDb', '#lyLen'].forEach(q => $(q).addEventListener('change', () => { if (PL.kind === 'combine') $('#cbPlay').click(), $('#cbPlay').click(); else auditionLayer(); }));
$('#lyOff').addEventListener('change', () => { if (PL.kind === 'combine'){ stopPlay(); $('#cbPlay').click(); } });
$('#lyVel').onclick = () => { ST.cb.layer.followVel = !ST.cb.layer.followVel; renderCombine(); };
function auditionLayer(){ const y = ST.cb.layer, s = layerSound(y.src), sr = SR(), chs = soundAt(s, sr), len = Math.min(chs[0].length, Math.round(y.lengthMs / 1000 * sr)), fo = Math.min(len >> 1, Math.round(0.03 * sr)); shot(chs.map(c => { const o = c.slice(0, len); for (let i = 0; i < fo; i++) o[len - 1 - i] *= i / fo; return o; }), sr, dbToGain(y.db)); }
$('#lyFile').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  try {
    const buf = await decode(await f.arrayBuffer()); if (buf.duration > 6) throw 0;
    let k = ST.db.kits.find(x => x.layerKicks);
    if (!k){ k = { id:'k' + uid(), name:'Loaded kicks', layerKicks:true, created:Date.now(), lanes:Object.fromEntries(LANES.map(l => [l, []])) }; }
    const s = { id:'s' + uid(), name:clean(f.name.replace(/\.[^.]+$/, '')), sr:buf.sampleRate, ch:trimStart(chansOf(buf)), gain:0, from:'file' };
    k.lanes.kick.push(s); await put('kits', k);
    ST.cb.layer.src = k.id + '|' + s.id; ST.cb.layer.on = true; renderCombine(); auditionLayer();
    toast('“' + s.name + '” is the layer kick. It is kept in the kit “Loaded kicks”.');
  } catch (err) { toast('Could not use that file. A single kick under 6 seconds works best.'); }
};
$('#cbPlay').onclick = () => {
  if (PL.kind === 'combine') return stopPlay();
  const r = cbRhythm(); if (!r) return; const k = cbKit();
  previewRhythm(r, k, layerCfg(), 'combine', r.name + ' × ' + k.name);
};
$('#projName').oninput = e => { ST.cb.projName = e.target.value; };
async function saveProject(withCur){
  const r = cbRhythm(); if (!r){ toast('Pick a rhythm first.'); return null; }
  const name = clean($('#projName').value) || clean(ST.cb.projName) || projDefault(r, cbKit());
  ST.cb.projName = name;
  if (!ST.cb.projId) ST.cb.projId = 'p' + uid();
  const rh = deepRh(r); if (!rh.id) rh.id = 'r' + uid();
  const kept = ST.vers.filter(v => v.kept || (withCur && v === ST.cur)).map(v => ({ n:v.n, seed:v.seed, s:{ ...v.s, locks:{ ...v.s.locks } }, kept:!!v.kept }));
  const p = { id:ST.cb.projId, name, created:Date.now(), updated:Date.now(), rhythm:rh, kitId:ST.cb.kitId, fallback:ST.cb.fallback, layer:{ ...ST.cb.layer, picked:ST.cb.layer.picked.slice() }, gen:{ ...ST.g, locks:{ ...ST.g.locks } }, versions:kept };
  const old = ST.db.projects.find(x => x.id === p.id); if (old) p.created = old.created;
  await put('projects', p); markDone('combine'); renderLib();
  return p;
}
$('#cbSave').onclick = async () => { const p = await saveProject(false); if (p) $('#cbSaved').textContent = 'Saved “' + p.name + '” in the Library. It keeps the rhythm, the kit, the layer kick and the kept versions.'; };

/* ================= 5 LONG BEAT ================= */
const KIND_NAME = { base:'Groove', var:'Small change', fill:'Fill', stop:'Stop', break:'Thinner bar' };
function kindCol(k){ return k === 'base' ? css('--grid-2') : k === 'var' ? laneCol('hat') : k === 'fill' ? css('--accent') : k === 'stop' ? css('--danger') : laneCol('perc'); }
function renderBeat(){
  const r = cbRhythm(), k = cbKit(), y = ST.cb.layer, g = ST.g;
  $('#gSrc').textContent = r ? 'Rhythm: ' + r.name + ' · Sounds: ' + k.name + (y.on ? ' · Layer kick on' : '') : 'No rhythm yet. Get one from a loop first.';
  segSet('#gStyle', g.style); segSet('#gPhrase', g.phrase);
  $('#gBpm').value = g.bpm; $('#gMin').value = g.minutes;
  $('#gAmt').value = g.amount; $('#gAmtOut').textContent = g.amount + '%';
  $('#gAmtSub').textContent = g.amount === 0 ? 'The groove repeats exactly, start to end.' : g.amount < 35 ? 'Mostly the groove. A ghost note here, a fill at the end of some phrases.' : g.amount < 70 ? 'The groove stays clear. Fills at phrase ends, a stop between parts, some ghost notes and hat changes.' : 'More happens, but the groove still leads. ' + (g.style === 'trap' ? 'Hat rolls and triplets often.' : 'Fills, pickups and open hats often.');
  $$('#gLocks button').forEach(b => b.setAttribute('aria-pressed', g.locks[b.dataset.v] ? 'true' : 'false'));
  $('#gHum').value = g.hum; $('#gHumOut').textContent = g.hum + ' ms';
  $('#gGlue').value = g.glue; $('#gGlueOut').textContent = g.glue + '%';
  $('#gMake').disabled = !r;
  const v = ST.cur; $('#gRes').hidden = !v; $('#gResEmpty').hidden = !!v; $('#gExport').hidden = !v;
  if (!v) return;
  $('#gTitle').textContent = 'Version ' + v.n;
  $('#gLegend').innerHTML = Object.keys(KIND_NAME).map(kd => '<span><i style="background:' + kindCol(kd) + '"></i>' + KIND_NAME[kd] + '</span>').join('') + '<span>Lighter rows: second part</span>';
  drawMap();
  $('#gVers').innerHTML = ST.vers.map(x => '<li class="ver' + (x === v ? ' cur' : '') + '" data-id="' + x.id + '"><button class="btn icon" data-a="play" aria-label="Play version ' + x.n + '">' + (PL.kind === 'beat' && PL.ver === x.id ? '■' : '▶') + '</button><div style="min-width:0"><b>Version ' + x.n + '</b><p class="meta">' + (x.s.style === 'trap' ? 'Trap' : 'Boom bap') + ' · ' + x.s.bpm + ' BPM · ' + fmtTime(x.dur) + ' · var ' + x.s.amount + '% · ' + esc(x.kitName) + '</p></div><div class="row">' + (x.kept ? '<span class="pill kept">Kept</span>' : '') + '<button class="btn small" data-a="pick">Show</button><button class="btn small danger" data-a="del" aria-label="Delete">×</button></div></li>').join('');
  $('#gKeep').textContent = v.kept ? '★ Kept' : '★ Keep this one'; $('#gKeep').setAttribute('aria-pressed', v.kept ? 'true' : 'false');
  updateExportHint();
}
function drawMap(){
  const v = ST.cur, cv = $('#gMap'), box = $('#gMapBox'); if (!v || !box.clientWidth) return;
  const w = box.clientWidth, per = w < 520 ? 8 : 16, cell = w / per, rows = Math.ceil(v.plan.length / per), ch = Math.max(16, Math.min(26, cell * 0.7)), h = rows * ch;
  const g = fit(cv, w, h); g.clearRect(0, 0, w, h);
  const cur = PL.kind === 'beat' && PL.ver === v.id ? Math.floor(playPos() / (60 / v.s.bpm) / 4) : -1;
  v.plan.forEach(p => {
    const x = (p.bar % per) * cell, y = Math.floor(p.bar / per) * ch;
    if (p.sec === 'B'){ g.fillStyle = css('--surface-2'); g.fillRect(x, y, cell, ch); }
    g.fillStyle = kindCol(p.kind); g.globalAlpha = p.kind === 'base' ? (p.sec === 'B' ? 0.35 : 0.6) : 1;
    g.fillRect(x + 1.5, y + 2, cell - 3, ch - 4); g.globalAlpha = 1;
    if (p.bar === cur){ g.strokeStyle = css('--ink'); g.lineWidth = 2.5; g.strokeRect(x + 1.5, y + 2, cell - 3, ch - 4); }
    if (p.bar % 8 === 0){ g.fillStyle = css('--ink'); g.font = '500 9px ' + css('--f-mono'); g.fillText(String(p.bar + 1), x + 3, y + ch - 5); }
  });
  cv._m = { per, cell, ch };
}
$('#gMapBox').onclick = e => {
  const v = ST.cur, m = $('#gMap')._m; if (!v || !m) return;
  const r = e.currentTarget.getBoundingClientRect(), bar = Math.floor((e.clientY - r.top) / m.ch) * m.per + Math.floor((e.clientX - r.left) / m.cell);
  if (bar >= 0 && bar < v.plan.length) playVersion(v, bar * 4 * 60 / v.s.bpm);
};
$$('#gStyle button').forEach(b => b.onclick = () => { ST.g.style = b.dataset.v; saveG(); renderBeat(); });
$$('#gPhrase button').forEach(b => b.onclick = () => { ST.g.phrase = +b.dataset.v; saveG(); renderBeat(); });
const setG = (k, v, lo, hi) => { if (!isFinite(v)) return; ST.g[k] = clamp(v, lo, hi); if (k === 'bpm') ST.gTouchedBpm = true; saveG(); renderBeat(); };
$('#gBpm').onchange = e => setG('bpm', Math.round(parseFloat(e.target.value) * 2) / 2, 50, 200);
$('#gBpmDown').onclick = () => setG('bpm', Math.round(ST.g.bpm) - 1, 50, 200);
$('#gBpmUp').onclick = () => setG('bpm', Math.round(ST.g.bpm) + 1, 50, 200);
$('#gMin').onchange = e => setG('minutes', Math.round(parseFloat(e.target.value) * 2) / 2, 0.5, 10);
$('#gMinDown').onclick = () => setG('minutes', ST.g.minutes - 0.5, 0.5, 10);
$('#gMinUp').onclick = () => setG('minutes', ST.g.minutes + 0.5, 0.5, 10);
$('#gAmt').oninput = e => { ST.g.amount = +e.target.value; saveG(); renderBeat(); };
$('#gHum').oninput = e => { ST.g.hum = +e.target.value; $('#gHumOut').textContent = ST.g.hum + ' ms'; saveG(); };
$('#gGlue').oninput = e => { ST.g.glue = +e.target.value; $('#gGlueOut').textContent = ST.g.glue + '%'; saveG(); };
$$('#gLocks button').forEach(b => b.onclick = () => { ST.g.locks[b.dataset.v] = !ST.g.locks[b.dataset.v]; saveG(); renderBeat(); });
function saveG(){ lsSet('gen', ST.g); }
function versionSeq(v, r){
  const bars = Math.max(v.s.phrase, Math.round(v.s.minutes * v.s.bpm / 4 / v.s.phrase) * v.s.phrase);
  return generateBeat(r, { bars, style:v.s.style, amount:v.s.amount / 100, locks:v.s.locks, seed:v.seed, phrase:v.s.phrase, humanizeMs:v.s.hum, bpm:v.s.bpm });
}
function renderVersion(v){
  const sr = SR(), kit = kitById(v.kitId) || builtin();
  const out = renderEvents(v.seq, kit, { sr, bpm:v.s.bpm, fallback:v.fallback || kit.builtin ? builtin() : null, layer:v.layer ? { ...v.layer, sound:layerSound(v.layer.src) } : null });
  master(out.L, out.R, v.s.glue / 100);
  return { L:out.L, R:out.R, sr };
}
async function makeVersion(){
  const r = cbRhythm(); if (!r) return;
  stopPlay();
  await busy('Making the beat…', async () => {
    const v = { id:'v' + uid(), n:++ST.nVer, seed:Math.floor(Math.random() * 2e9), s:{ ...ST.g, locks:{ ...ST.g.locks } }, kept:false, rhythm:deepRh(r), kitId:ST.cb.kitId, kitName:cbKit().name, fallback:ST.cb.fallback, layer:ST.cb.layer.on ? { ...ST.cb.layer, picked:ST.cb.layer.picked.slice() } : null };
    v.seq = versionSeq(v, v.rhythm); v.plan = v.seq.plan; v.dur = v.seq.beats * 60 / v.s.bpm;
    await tick();
    v.audio = renderVersion(v);
    ST.vers.forEach(x => { if (x !== v) x.audio = null; });
    ST.vers.unshift(v); ST.cur = v;
    const loose = ST.vers.filter(x => !x.kept); if (loose.length > 6) ST.vers = ST.vers.filter(x => x.kept || loose.indexOf(x) < 6);
  });
  markDone('beat'); renderBeat(); playVersion(ST.cur, 0);
}
async function ensureAudio(v){ if (!v.audio){ await busy('Getting version ' + v.n + ' ready…', async () => { ST.vers.forEach(x => { if (x !== v) x.audio = null; }); if (!v.seq){ v.seq = versionSeq(v, v.rhythm); v.plan = v.seq.plan; } v.audio = renderVersion(v); }); } return v.audio; }
async function playVersion(v, from){
  const a = await ensureAudio(v);
  playBuf([a.L, a.R], a.sr, { loop:false, from, label:'Version ' + v.n + ' · ' + (v.rhythm.name || 'Beat'), kind:'beat', bpm:v.s.bpm });
  PL.ver = v.id; renderBeat();
}
$('#gMake').onclick = makeVersion;
$('#gAgain').onclick = makeVersion;
$('#gPlay').onclick = () => { if (PL.kind === 'beat' && PL.ver === ST.cur.id) return stopPlay(); playVersion(ST.cur, 0); };
$('#gKeep').onclick = () => { if (!ST.cur) return; ST.cur.kept = !ST.cur.kept; renderBeat(); if (ST.cur.kept) toast('Kept. “Make another” adds a new version next to it. Save the project to keep it for later.'); };
$('#gVers').addEventListener('click', e => {
  const b = e.target.closest('button[data-a]'); if (!b) return;
  const v = ST.vers.find(x => x.id === b.closest('.ver').dataset.id); if (!v) return;
  if (b.dataset.a === 'play'){ if (PL.kind === 'beat' && PL.ver === v.id) stopPlay(); else { ST.cur = v; playVersion(v, 0); } }
  if (b.dataset.a === 'pick'){ ST.cur = v; renderBeat(); }
  if (b.dataset.a === 'del'){ if (PL.ver === v.id) stopPlay(); ST.vers = ST.vers.filter(x => x !== v); if (ST.cur === v) ST.cur = ST.vers[0] || null; renderBeat(); }
});
const verName = v => fileBase(v.rhythm.name + ' ' + (v.s.style === 'trap' ? 'trap' : 'boombap') + ' ' + v.s.bpm + 'bpm v' + v.n);
$('#exMix').onclick = async () => {
  const v = ST.cur; if (!v) return;
  const a = await ensureAudio(v), nm = verName(v);
  let files;
  await busy('Writing the WAV…', async () => { files = [{ name:nm + '.wav', data:encodeWav([a.L, a.R], a.sr, 24) }, { name:nm + '.mid', data:encodeMidi(v.seq, v.s.bpm, nm, v.layer) }]; });
  await giveFiles(nm + '.zip', files);
};
$('#exStems').onclick = async () => {
  const v = ST.cur; if (!v) return; const nm = verName(v), files = [];
  await busy('Writing the separate tracks…', async () => {
    const sr = SR(), kit = kitById(v.kitId) || builtin(), opt = { sr, bpm:v.s.bpm, fallback:v.fallback || kit.builtin ? builtin() : null, layer:v.layer ? { ...v.layer, sound:layerSound(v.layer.src) } : null };
    const full = renderEvents(v.seq, kit, opt); let pk = 0; for (let i = 0; i < full.n; i++) pk = Math.max(pk, Math.abs(full.L[i]), Math.abs(full.R[i]));
    const gain = pk > 0 ? 0.891 / pk : 1;
    const groups = [['kick', ['kick']], ['snare', ['snare']], ['hats', ['hat', 'ohat']], ['other', ['perc']]]; if (v.layer) groups.push(['layer kick', ['layer']]);
    for (const [name, only] of groups){
      if (!v.seq.events.some(e => only.includes(e.lane) || (only[0] === 'layer' && layerWanted(e, v.layer)))) continue;
      const o = renderEvents(v.seq, kit, { ...opt, only });
      for (let i = 0; i < o.n; i++){ o.L[i] *= gain; o.R[i] *= gain; }
      files.push({ name:nm + ' ' + name + '.wav', data:encodeWav([o.L, o.R], sr, 24) });
      await tick();
    }
    files.push({ name:nm + '.mid', data:encodeMidi(v.seq, v.s.bpm, nm, v.layer) });
  });
  await giveFiles(nm + ' tracks.zip', files);
};
$('#gSaveProj').onclick = async () => { if (ST.cur && !ST.cur.kept){ ST.cur.kept = true; } const p = await saveProject(true); if (p){ renderBeat(); toast('Saved “' + p.name + '” with ' + p.versions.length + (p.versions.length === 1 ? ' version.' : ' versions.')); } };

/* ================= LIBRARY ================= */
const when = t => new Date(t || Date.now()).toLocaleString('en-GB', { day:'numeric', month:'short', hour:'2-digit', minute:'2-digit' });
let armDel = null;
function libItem(kind, it, sub, acts){
  return '<li class="li" data-k="' + kind + '" data-id="' + esc(it.id) + '"><div><b>' + esc(it.name) + '</b><p class="meta">' + esc(sub) + '</p></div><div class="acts">' + acts.map(([a, t, c]) => '<button class="btn small' + (c ? ' ' + c : '') + '" data-a="' + a + '">' + t + '</button>').join('') + '<button class="btn small danger" data-a="del">' + (armDel === kind + it.id ? 'Tap again to delete' : 'Delete') + '</button></div></li>';
}
function renderLib(){
  if (!$('#libProj')) return;
  const P = ST.db.projects, R = ST.db.rhythms, K = ST.db.kits;
  $('#libProj').innerHTML = P.length ? P.map(p => libItem('p', p, when(p.updated) + ' · ' + (p.versions || []).length + ' kept versions', [['open', 'Open', 'primary'], ['file', 'Save file']])).join('') : '<li class="empty">No projects yet. Save one in Combine or Long beat.</li>';
  $('#libRh').innerHTML = R.length ? R.map(r => libItem('r', r, r.bpm + ' BPM · ' + r.bars + ' bars · ' + r.hits.length + ' hits', [['open', 'Edit'], ['use', 'Use in Combine'], ['file', 'Save file']])).join('') : '<li class="empty">No rhythms yet. Save one in step 2.</li>';
  $('#libKits').innerHTML = K.length ? K.map(k => libItem('k', k, LANES.map(l => (k.lanes[l] || []).length ? (k.lanes[l].length + ' ' + LANE_SHORT[l]) : '').filter(Boolean).join(' · ') || 'Empty', [['use', 'Use in Combine'], ['ren', 'Rename'], ['file', 'Save file']])).join('') : '<li class="empty">No kits yet. Save sounds in step 3.</li>';
  $('#libNote').textContent = (DB.mem ? 'This browser does not let the page store things, so the Library lasts until the page closes. ' : 'The Library is stored in this browser on this device. ') +
    'To move work to another device or keep a backup, save a file. Project files include the sounds. Open the file on the other device with the button below.';
}
$('#v-lib').addEventListener('click', async e => {
  const b = e.target.closest('button[data-a]'), li = e.target.closest('.li'); if (!b || !li) return;
  const k = li.dataset.k, id = li.dataset.id, a = b.dataset.a, store = { p:'projects', r:'rhythms', k:'kits' }[k], it = ST.db[store].find(x => x.id === id); if (!it) return;
  if (a === 'del'){
    if (armDel !== k + id){ armDel = k + id; renderLib(); setTimeout(() => { if (armDel === k + id){ armDel = null; renderLib(); } }, 3000); return; }
    armDel = null; await del(store, id);
    if (k === 'k' && ST.cb.kitId === id) ST.cb.kitId = 'builtin';
    if (k === 'r' && ST.cb.rhId === id) ST.cb.rhId = 'work';
    refreshSelects(); renderLib(); return;
  }
  if (a === 'file'){ await saveFileFor(k, it); return; }
  if (k === 'r' && a === 'open'){ ST.rh = deepRh(it); ST.rhFromLib = true; ST.rhEdited = false; ST.sel = null; ST.cb.rhId = it.id; refreshSelects(); go('rhythm'); return; }
  if (k === 'r' && a === 'use'){ ST.cb.rhId = it.id; if (!ST.gTouchedBpm) ST.g.bpm = Math.round(it.bpm * 2) / 2; go('combine'); return; }
  if (k === 'k' && a === 'use'){ ST.cb.kitId = it.id; go('combine'); return; }
  if (k === 'k' && a === 'ren'){
    li.querySelector('div').innerHTML = '<input type="text" id="renIn" maxlength="60" value="' + esc(it.name) + '" aria-label="Kit name"><div class="row" style="margin-top:6px"><button class="btn small primary" id="renOk">Save name</button></div>';
    const inp = $('#renIn'); inp.focus(); $('#renOk').onclick = async () => { it.name = clean(inp.value) || it.name; await put('kits', it); refreshSelects(); renderLib(); };
    return;
  }
  if (k === 'p' && a === 'open') openProject(it);
});
function openProject(p){
  stopPlay();
  let r = ST.db.rhythms.find(x => x.id === p.rhythm.id);
  if (!r){ r = deepRh(p.rhythm); put('rhythms', r); }
  ST.cb.rhId = r.id; ST.cb.projId = p.id; ST.cb.projName = p.name;
  if (p.kitId && !kitById(p.kitId)) toast('The kit for this project is missing on this device. Open its project file to bring it back.');
  ST.cb.kitId = kitById(p.kitId) ? p.kitId : 'builtin'; ST.cb.fallback = p.fallback !== false;
  ST.cb.layer = Object.assign({ on:false, src:HARD_KICK_ID, mode:'strong', db:-4, offsetMs:0, lengthMs:420, followVel:true, picked:[] }, p.layer || {});
  ST.g = Object.assign({}, ST.g, p.gen || {}); ST.gTouchedBpm = true;
  ST.vers = (p.versions || []).map(x => ({ id:'v' + uid(), n:x.n, seed:x.seed, s:x.s, kept:true, rhythm:deepRh(r), kitId:ST.cb.kitId, kitName:cbKit().name, fallback:ST.cb.fallback, layer:ST.cb.layer.on ? { ...ST.cb.layer } : null }));
  ST.vers.forEach(v => { v.seq = versionSeq(v, v.rhythm); v.plan = v.seq.plan; v.dur = v.seq.beats * 60 / v.s.bpm; });
  ST.nVer = Math.max(0, ...ST.vers.map(v => v.n)); ST.cur = ST.vers[0] || null;
  refreshSelects(); go(ST.cur ? 'beat' : 'combine');
  toast('Opened “' + p.name + '”.');
}
const APP = 'norwegian-breaks';
async function saveFileFor(k, it){
  let doc;
  await busy('Packing the file…', async () => {
    if (k === 'r') doc = { app:APP, v:1, type:'rhythm', rhythm:deepRh(it) };
    if (k === 'k') doc = { app:APP, v:1, type:'kit', kit:packKit(it) };
    if (k === 'p'){
      const kits = [], kk = kitById(it.kitId); if (kk && !kk.builtin) kits.push(packKit(kk));
      const ls = it.layer && it.layer.src && it.layer.src.includes('|') ? kitById(it.layer.src.split('|')[0]) : null; if (ls && !kits.some(x => x.id === ls.id)) kits.push(packKit(ls));
      doc = { app:APP, v:1, type:'project', project:it, kits };
    }
  });
  const suffix = { r:' rhythm', k:' kit', p:'' }[k];
  await giveFiles(fileBase(it.name + suffix) + '.json', [{ name:fileBase(it.name + suffix) + '.json', data:new TextEncoder().encode(JSON.stringify(doc)) }]);
}
$('#backupAll').onclick = async () => {
  let data;
  await busy('Packing everything…', async () => { data = new TextEncoder().encode(JSON.stringify({ app:APP, v:1, type:'backup', rhythms:ST.db.rhythms.map(deepRh), kits:ST.db.kits.map(packKit), projects:ST.db.projects })); });
  const d = new Date(), nm = 'Norwegian Breaks backup ' + d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0') + '.json';
  await giveFiles(nm, [{ name:nm, data }]);
};
$('#impFile').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  try {
    let n = 0;
    await busy('Opening the file…', async () => {
      const doc = JSON.parse(await f.text()); if (!doc || doc.app !== APP) throw 0;
      const rhs = doc.rhythms || (doc.rhythm ? [doc.rhythm] : []), kits = doc.kits || (doc.kit ? [doc.kit] : []), prs = doc.projects || (doc.project ? [doc.project] : []);
      for (const r of rhs){ await put('rhythms', deepRh(r)); n++; }
      for (const k of kits){ await put('kits', unpackKit(k)); n++; }
      for (const p of prs){ await put('projects', p); n++; if (p.rhythm && !ST.db.rhythms.some(r => r.id === p.rhythm.id)) await put('rhythms', deepRh(p.rhythm)); }
    });
    refreshSelects(); renderLib(); toast('Added ' + n + (n === 1 ? ' item' : ' items') + ' to the Library.');
  } catch (err) { toast('That is not a Norwegian Breaks file.'); }
};

/* ---------- playheads, resize, theme ---------- */
function drawPlayheads(){
  if (ST.view === 'loop') drawLoopWave();
  if (ST.view === 'rhythm' && ST.rh) drawGrid($('#rhGrid'), $('#rhWrap'), ST.rh, ST.sel, PL.kind === 'rhkit' || PL.kind === 'orig');
  if (ST.view === 'combine'){ const r = cbRhythm(); if (r) drawGrid($('#cbGrid'), $('#cbWrap'), r, null, PL.kind === 'combine', layerCfg()); }
  if (ST.view === 'beat') drawMap();
}
function redraw(){ if (ST.view === 'sounds') renderSounds(); else drawPlayheads(); }
let rzT = 0; const onRz = () => { clearTimeout(rzT); rzT = setTimeout(redraw, 120); };
window.addEventListener('resize', onRz);
try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', redraw); } catch (e) {}
try { new MutationObserver(redraw).observe(document.documentElement, { attributes:true, attributeFilter:['data-theme'] }); } catch (e) {}
document.addEventListener('keydown', e => { if (e.code === 'Space' && !/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName) && PL.src){ e.preventDefault(); stopPlay(); } });

/* ---------- start: open on the example break so every step shows something ---------- */
(async function boot(){
  initDb();
  setLoop((() => { const ex = exampleLoop(SR()); return { name:ex.name, ch:ex.ch, sr:ex.sr, bpm:ex.bpm, bars:ex.bars }; })());
  ST.done = {}; $$('.steps button').forEach(b => b.classList.remove('done'));
  renderLoop(); renderLib(); updateExportHint();
})();

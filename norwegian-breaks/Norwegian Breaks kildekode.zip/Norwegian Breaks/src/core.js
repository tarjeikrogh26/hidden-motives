/* ================= CORE: analysis, slicing, generator, render, files (no DOM) ================= */
const LANES = ['kick', 'snare', 'hat', 'ohat', 'perc'];
const LANE_NAME = { kick:'Kick', snare:'Snare', hat:'Hi-hat', ohat:'Open hat', perc:'Other', layer:'Layer kick' };
const LANE_SHORT = { kick:'K', snare:'S', hat:'H', ohat:'OH', perc:'X' };
const GM = { kick:36, snare:38, hat:42, ohat:46, perc:39, layer:35 };
const PAN = { kick:0, snare:0, hat:0.14, ohat:0.2, perc:-0.18, layer:0 };
const LOCK_OF = { kick:'kick', snare:'snare', hat:'hat', ohat:'hat', perc:'perc' };

function mulberry(seed){
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const dbToGain = d => Math.pow(10, d / 20);
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

/* ---------- FFT (radix-2, in place) ---------- */
const FFT_T = {};
function fftTables(N){
  if (FFT_T[N]) return FFT_T[N];
  const rev = new Uint32Array(N), cos = new Float64Array(N / 2), sin = new Float64Array(N / 2), bits = Math.log2(N);
  for (let i = 0; i < N; i++){ let r = 0; for (let b = 0; b < bits; b++) r |= ((i >> b) & 1) << (bits - 1 - b); rev[i] = r; }
  for (let i = 0; i < N / 2; i++){ cos[i] = Math.cos(-2 * Math.PI * i / N); sin[i] = Math.sin(-2 * Math.PI * i / N); }
  return (FFT_T[N] = { rev, cos, sin });
}
function fft(re, im){
  const N = re.length, T = fftTables(N);
  for (let i = 0; i < N; i++){ const j = T.rev[i]; if (j > i){ let t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; } }
  for (let size = 2; size <= N; size <<= 1){
    const half = size >> 1, step = N / size;
    for (let s = 0; s < N; s += size){
      for (let k = 0; k < half; k++){
        const c = T.cos[k * step], si = T.sin[k * step], a = s + k, b = a + half;
        const tr = re[b] * c - im[b] * si, ti = re[b] * si + im[b] * c;
        re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
      }
    }
  }
}

function toMono(chs){
  if (chs.length === 1) return chs[0];
  const n = chs[0].length, m = new Float32Array(n);
  for (let c = 0; c < chs.length; c++){ const x = chs[c]; for (let i = 0; i < n; i++) m[i] += x[i]; }
  for (let i = 0; i < n; i++) m[i] /= chs.length;
  return m;
}
function peakOf(chs){ let p = 0; chs.forEach(x => { for (let i = 0; i < x.length; i++){ const a = Math.abs(x[i]); if (a > p) p = a; } }); return p; }
/* Peak-hold envelope: rises instantly, falls with a release time. Keeps attack timing exact. */
function envelope(x, sr, releaseMs){
  const n = x.length, e = new Float32Array(n), r = Math.exp(-1 / (sr * releaseMs / 1000));
  let v = 0;
  for (let i = 0; i < n; i++){ const a = Math.abs(x[i]); v = a > v ? a : v * r; e[i] = v; }
  return e;
}
function biquad(type, f, Q, sr){
  const w = 2 * Math.PI * f / sr, cs = Math.cos(w), al = Math.sin(w) / (2 * Q);
  let b0, b1, b2;
  if (type === 'hp'){ b0 = (1 + cs) / 2; b1 = -(1 + cs); b2 = b0; } else { b0 = (1 - cs) / 2; b1 = 1 - cs; b2 = b0; }
  const a0 = 1 + al;
  return { b0:b0 / a0, b1:b1 / a0, b2:b2 / a0, a1:-2 * cs / a0, a2:(1 - al) / a0 };
}
function filt(x, c){
  const y = new Float32Array(x.length); let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let i = 0; i < x.length; i++){ const v = x[i], o = c.b0 * v + c.b1 * x1 + c.b2 * x2 - c.a1 * y1 - c.a2 * y2; x2 = x1; x1 = v; y2 = y1; y1 = o; y[i] = o; }
  return y;
}

/* ---------- onset analysis ---------- */
const BANDS = [[30, 150], [150, 600], [600, 3500], [5000, 16000]];   // low · low-mid · mid · high
function bandEnergies(x, from, len, sr, N){
  const re = new Float64Array(N), im = new Float64Array(N), out = [0, 0, 0, 0];
  for (let i = 0; i < Math.min(len, N); i++){
    const j = from + i; if (j < 0 || j >= x.length) continue;
    const w = i < 32 ? i / 32 : i > len - 64 ? Math.max(0, (len - i) / 64) : 1;
    re[i] = x[j] * w;
  }
  fft(re, im);
  const hz = sr / N;
  for (let b = 0; b < BANDS.length; b++){
    const k0 = Math.max(1, Math.floor(BANDS[b][0] / hz)), k1 = Math.min(N / 2 - 1, Math.ceil(BANDS[b][1] / hz));
    let s = 0; for (let k = k0; k <= k1; k++) s += re[k] * re[k] + im[k] * im[k];
    out[b] = s;
  }
  return out;
}

/* Finds drum hits in a loop and suggests what each one is.
   Returns onsets [{t (s), at (sample), labels[], amp{lane}, open, flags{overlap,bleed}, feat}] */
function analyzeLoop(chs, sr, opt = {}){
  const sens = opt.sens == null ? 0.5 : opt.sens;          // 0 … 1 (higher finds more)
  let x = toMono(chs);
  const pk = peakOf([x]) || 1; if (pk !== 1){ const y = new Float32Array(x.length); for (let i = 0; i < x.length; i++) y[i] = x[i] / pk; x = y; }
  const n = x.length, N = sr > 60000 ? 2048 : 1024, hop = Math.max(64, Math.round(sr * 0.0029));
  const frames = Math.max(1, Math.floor((n + N) / hop) + 1);   // frame f covers [f·hop − N, f·hop), so a hit at sample 0 still shows a rise
  const win = new Float64Array(N); for (let i = 0; i < N; i++) win[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / N);
  const hz = sr / N, ranges = BANDS.map(([a, b]) => [Math.max(1, Math.floor(a / hz)), Math.min(N / 2 - 1, Math.ceil(b / hz))]);
  const E = BANDS.map(() => new Float32Array(frames));
  const re = new Float64Array(N), im = new Float64Array(N);
  for (let f = 0; f < frames; f++){
    const s0 = f * hop - N;
    for (let i = 0; i < N; i++){ const j = s0 + i; re[i] = j >= 0 && j < n ? x[j] * win[i] : 0; im[i] = 0; }
    fft(re, im);
    for (let b = 0; b < ranges.length; b++){ let s = 0; for (let k = ranges[b][0]; k <= ranges[b][1]; k++) s += re[k] * re[k] + im[k] * im[k]; E[b][f] = s; }
  }
  // log-compressed spectral flux per band, each band scaled to its own maximum
  const nov = new Float32Array(frames), W = [1, 0.7, 1, 1];
  for (let b = 0; b < E.length; b++){
    let mx = 0; for (let f = 0; f < frames; f++) mx = Math.max(mx, E[b][f]);
    if (mx <= 0) continue;
    const lg = new Float32Array(frames); for (let f = 0; f < frames; f++) lg[f] = Math.log(1 + 1000 * E[b][f] / mx);
    const fl = new Float32Array(frames); let fm = 0;
    for (let f = 1; f < frames; f++){ const d = Math.max(lg[f] - lg[f - 1], f > 1 ? (lg[f] - lg[f - 2]) * 0.7 : 0, 0); fl[f] = d; if (d > fm) fm = d; }
    if (fm > 0) for (let f = 0; f < frames; f++) nov[f] += W[b] * fl[f] / fm;
  }
  let nmax = 0; for (let f = 0; f < frames; f++) nmax = Math.max(nmax, nov[f]);
  const delta = (0.2 - 0.17 * sens) * nmax, wPk = Math.max(2, Math.round(0.022 * sr / hop)), wAvg = Math.round(0.09 * sr / hop);
  const cand = [];
  for (let f = 1; f < frames; f++){
    const v = nov[f]; if (v <= 0) continue;
    let isMax = true; for (let k = Math.max(0, f - wPk); k <= Math.min(frames - 1, f + wPk); k++) if (nov[k] > v || (nov[k] === v && k < f)){ isMax = false; break; }
    if (!isMax) continue;
    let s = 0, c = 0; for (let k = Math.max(0, f - wAvg); k <= Math.min(frames - 1, f + wAvg); k++){ s += nov[k]; c++; }
    if (v > s / c * (1.35 - 0.3 * sens) + delta) cand.push({ f, v });
  }
  // refine each onset to the sample with the envelope
  const env = envelope(x, sr, 18), ons = [];
  for (const c of cand){
    const ctr = c.f * hop - N / 2, a = Math.max(0, ctr - Math.round(N * 0.55)), b = Math.min(n - 1, ctr + Math.round(N * 0.45));
    let p = a; for (let i = a; i <= b; i++) if (env[i] > env[p]) p = i;
    const back = Math.max(0, p - Math.round(0.03 * sr));
    let base = env[p]; for (let i = back; i <= p; i++) if (env[i] < base) base = env[i];
    const th = base + 0.16 * (env[p] - base);
    let o = p; while (o > back && env[o - 1] > th) o--;
    ons.push({ at:o, peak:env[p], v:c.v });
  }
  ons.sort((p, q) => p.at - q.at);
  const minGap = Math.round(0.028 * sr), merged = [];
  for (const o of ons){ const last = merged[merged.length - 1]; if (last && o.at - last.at < minGap){ if (o.v > last.v) merged[merged.length - 1] = o; } else merged.push(o); }
  // features
  const FN = sr > 60000 ? 4096 : 2048, look = Math.round(0.045 * sr), hpX = filt(filt(x, biquad('hp', 6000, 0.7, sr)), biquad('hp', 6000, 0.7, sr)), hEnv = envelope(hpX, sr, 8);
  const res = merged.map((o, i) => {
    const next = i + 1 < merged.length ? merged[i + 1].at : n;
    const len = Math.min(look, next - o.at);
    const aft = bandEnergies(x, o.at, Math.max(len, Math.round(0.012 * sr)), sr, FN);
    const bef = bandEnergies(x, o.at - look - 16, look, sr, FN);
    const inc = aft.map((v, b) => Math.max(0, v - 0.8 * bef[b] * Math.max(len, 1) / look));
    // high-band decay: how long the hiss rings (open hat check)
    let hp = 0, hpAt = o.at; for (let k = o.at; k < Math.min(n, o.at + Math.round(0.02 * sr)); k++) if (hEnv[k] > hp){ hp = hEnv[k]; hpAt = k; }
    let d = hpAt; while (d < next && d < n && hEnv[d] > hp * 0.12) d++;
    const decay = (d - o.at) / sr, cutHigh = d >= next && hEnv[Math.min(n - 1, next - 1)] > hp * 0.3;
    const totA = Math.sqrt(aft.reduce((s, v) => s + v, 0)), totB = Math.sqrt(bef.reduce((s, v) => s + v, 0));
    return { t:o.at / sr, at:o.at, amp:inc.map(Math.sqrt), decay, cutHigh, gapS:(next - o.at) / sr, bleed:totB > 0.32 * totA };
  });
  // per-band scale: the mean of the loudest fifth, so one odd loud hit does not squash the rest
  const bmax = [0, 1, 2, 3].map(b => { const v = res.map(r => r.amp[b]).sort((p, q) => q - p), k = Math.max(2, Math.ceil(v.length * 0.2)); let s = 0; for (let i = 0; i < Math.min(k, v.length); i++) s += v[i]; return Math.max(1e-9, s / Math.min(k, v.length || 1)); });
  res.forEach(r => {
    const a = r.amp.map((v, b) => Math.min(1.5, v / bmax[b])), m = Math.max(...a) || 1, s = a.map(v => v / m);
    const L = [];
    const isSnare = s[2] >= 0.62 && a[2] >= 0.08;
    const isKick = s[0] >= 0.6 && a[0] >= 0.08;
    if (isKick) L.push('kick');
    if (isSnare) L.push('snare');
    if (!isSnare && s[3] >= (isKick ? 0.55 : 0.5) && s[2] < 0.62) L.push(r.decay >= 0.14 || (r.cutHigh && r.gapS >= 0.12) ? 'ohat' : 'hat');
    if (!L.length) L.push(s[1] >= 0.6 && a[1] >= 0.1 ? 'perc' : s[3] >= s[2] ? 'hat' : 'perc');
    r.labels = L; r.norm = a;
    r.flags = { overlap:L.length > 1, bleed:r.bleed };
  });
  // velocities relative to the loudest hit of the same kind
  const laneAmp = { kick:0, snare:2, hat:3, ohat:3, perc:1 }, lmax = {};
  res.forEach(r => r.labels.forEach(l => { lmax[l] = Math.max(lmax[l] || 0, r.norm[laneAmp[l]]); }));
  res.forEach(r => { r.vel = {}; r.labels.forEach(l => { r.vel[l] = clamp(Math.pow(r.norm[laneAmp[l]] / (lmax[l] || 1), 0.85), 0.08, 1); }); });
  return res;
}

/* Tempo from the loop length, checked against how well hits sit on a 16th grid. */
function guessTempo(dur, onsets){
  let best = null;
  for (const bars of [1, 2, 4, 8]){
    const bpm = 240 * bars / dur; if (bpm < 58 || bpm > 185) continue;
    const step = 60 / bpm / 4;
    let err = 0; onsets.forEach(o => { const q = o.t / step; err += Math.pow(q - Math.round(q), 2); });
    err = onsets.length ? err / onsets.length : 0;
    const sc = err * 4 + Math.abs(Math.log2(bpm / 92));
    if (!best || sc < best.sc) best = { bpm, bars, sc };
  }
  if (!best){ const bpm = 92; return { bpm, bars:Math.max(1, Math.round(dur * bpm / 240)) }; }
  return { bpm:Math.round(best.bpm * 100) / 100, bars:best.bars };
}

/* A rhythm: hit positions in beats, independent of any sound. */
function rhythmFromOnsets(onsets, bpm, bars, startSec){
  const spb = 60 / bpm, total = bars * 4, hits = [];
  onsets.forEach((o, i) => {
    let pos = (o.t - startSec) / spb;
    if (pos < 0) pos += total;
    if (pos < 0 || pos >= total) return;
    o.labels.forEach(l => hits.push({ id:'h' + i + l, pos, lane:l, vel:o.vel[l], src:i }));
  });
  hits.sort((a, b) => a.pos - b.pos);
  return hits;
}
const slotOfPos = p => Math.round(p * 4);
function grooveOf(r){
  const sum = {}, cnt = {}, all = [0, 0, 0, 0], ac = [0, 0, 0, 0];
  r.hits.forEach(h => {
    const q = slotOfPos(h.pos), sub = ((q % 4) + 4) % 4, off = h.pos - q / 4;
    const k = h.lane + sub; sum[k] = (sum[k] || 0) + off; cnt[k] = (cnt[k] || 0) + 1; all[sub] += off; ac[sub]++;
  });
  const off = (lane, sub) => { const k = lane + sub; if (cnt[k]) return sum[k] / cnt[k]; if (ac[sub]) return all[sub] / ac[sub]; return sub % 2 ? (all[2] / (ac[2] || 1)) : 0; };
  // swing: how late the 16th off-beats sit, as the classic MPC percentage
  const s13 = (ac[1] + ac[3]) ? (all[1] + all[3]) / (ac[1] + ac[3]) : 0, s02 = (ac[0] + ac[2]) ? (all[0] + all[2]) / (ac[0] + ac[2]) : 0;
  const swing = clamp(50 + (s13 - s02) / 0.25 * 50, 40, 75);
  const lateMs = {}; const spb = 60 / r.bpm;
  LANES.forEach(l => { const hs = r.hits.filter(h => h.lane === l && slotOfPos(h.pos) % 2 === 0); if (hs.length) lateMs[l] = hs.reduce((s, h) => s + (h.pos - slotOfPos(h.pos) / 4), 0) / hs.length * spb * 1000; });
  return { off, swing, lateMs };
}

/* ---------- slicing ---------- */
function suggestSlices(chs, sr, onsets){
  const x = toMono(chs), n = x.length, env = envelope(x, sr, 25);
  return onsets.map((o, i) => {
    const start = Math.max(0, o.at - Math.round(0.0015 * sr));
    const next = i + 1 < onsets.length ? onsets[i + 1].at : n;
    let p = 0; for (let k = o.at; k < Math.min(n, o.at + Math.round(0.03 * sr)); k++) p = Math.max(p, env[k]);
    let e = o.at; const hard = Math.min(n, o.at + Math.round(1.6 * sr));
    while (e < hard && env[e] > p * 0.006) e++;
    const end = Math.min(e, Math.max(start + Math.round(0.03 * sr), next - Math.round(0.0008 * sr)));
    return { id:'s' + i, on:i, start, end, natEnd:e, lane:o.labels[0], labels:o.labels.slice(), keep:false, fadeIn:0.6, fadeOut:end < e ? 18 : 6, gain:0 };
  });
}
/* env: envelope(toMono(loop), sr, 25), computed once per loop */
function sliceFlags(sl, onsets, env, sr){
  const o = onsets[sl.on], out = [];
  let p = 0; for (let k = sl.start; k < Math.min(sl.end, sl.start + Math.round(0.03 * sr)); k++) p = Math.max(p, env[k]);
  if (o && o.labels.length > 1) out.push({ k:'overlap', t:o.labels.map(l => LANE_NAME[l].toLowerCase()).join(' + ') + ' hit together. Both stay in this sound.' });
  if (o && o.bleed) out.push({ k:'bleed', t:'The hit before is still ringing underneath.' });
  const inside = onsets.filter(q => q.at > sl.start + Math.round(0.012 * sr) && q.at < sl.end).length;
  if (inside) out.push({ k:'more', t:inside === 1 ? 'The cut runs into the next hit.' : 'The cut runs into ' + inside + ' more hits.' });
  else if (sl.end < sl.natEnd && env[Math.min(env.length - 1, sl.end)] > p * 0.1) out.push({ k:'cut', t:'The tail is cut short. A longer fade-out hides it.' });
  return out;
}
/* Copies a slice out with short fades against clicks. Attack is kept: the fade-in is under 1 ms. */
function extractSlice(chs, sr, sl){
  const len = Math.max(8, sl.end - sl.start), fi = Math.max(1, Math.round(sl.fadeIn / 1000 * sr)), fo = Math.max(1, Math.round(sl.fadeOut / 1000 * sr));
  const g = dbToGain(sl.gain || 0);
  return chs.map(c => {
    const y = c.slice(sl.start, sl.start + len);
    for (let i = 0; i < y.length; i++){
      let w = g; if (i < fi) w *= i / fi; const r = y.length - 1 - i; if (r < fo) w *= Math.pow(r / fo, 1.5);
      y[i] *= w;
    }
    return y;
  });
}

/* ---------- built-in sounds (synthesized; used for the example loop, the hard kick and as a stand-in) ---------- */
function noiseGen(seed){ let s = seed >>> 0 || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296 * 2 - 1; }; }
function synth(kind, sr, v = {}){
  const dur = { kick:0.5, hard:0.9, snare:0.32, hat:0.07, ohat:0.42, perc:0.12 }[kind], n = Math.round(dur * sr), y = new Float32Array(n), nz = noiseGen(v.seed || 7 + kind.length);
  let ph = 0;
  const lpS = biquad('lp', 5200, 0.7, sr);
  if (kind === 'kick' || kind === 'hard'){
    const hard = kind === 'hard', f0 = hard ? 190 : 120, f1 = hard ? 47 : 52, tau = hard ? 0.032 : 0.045, dec = hard ? 2.6 : 6.5;
    for (let i = 0; i < n; i++){
      const t = i / sr, f = f1 + (f0 - f1) * Math.exp(-t / tau); ph += f / sr;
      let s = Math.sin(2 * Math.PI * ph) * Math.exp(-t * dec) * Math.min(1, t / 0.0006);
      s += nz() * Math.exp(-t * (hard ? 260 : 380)) * (hard ? 0.45 : 0.25);
      y[i] = Math.tanh(s * (hard ? 2.2 : 1.4)) * (hard ? 0.9 : 0.85);
    }
  } else if (kind === 'snare'){
    const hp = biquad('hp', 900, 0.7, sr); const raw = new Float32Array(n); for (let i = 0; i < n; i++) raw[i] = nz();
    const hn = filt(filt(raw, hp), lpS);
    for (let i = 0; i < n; i++){
      const t = i / sr; ph += (185 + 40 * Math.exp(-t / 0.01)) / sr;
      y[i] = (Math.sin(2 * Math.PI * ph) * Math.exp(-t * 26) * 0.55 + hn[i] * Math.exp(-t * 15) * 0.85) * Math.min(1, t / 0.0005);
    }
  } else if (kind === 'hat' || kind === 'ohat'){
    const raw = new Float32Array(n); for (let i = 0; i < n; i++) raw[i] = nz();
    const hn = filt(filt(raw, biquad('hp', 7200, 0.8, sr)), biquad('hp', 7200, 0.8, sr)), d = kind === 'hat' ? 70 : 7;
    for (let i = 0; i < n; i++){ const t = i / sr; y[i] = hn[i] * Math.exp(-t * d) * 0.9 * Math.min(1, t / 0.0003); }
  } else {
    for (let i = 0; i < n; i++){ const t = i / sr; ph += 820 / sr; y[i] = (Math.sin(2 * Math.PI * ph) * 0.6 + nz() * 0.25) * Math.exp(-t * 45) * Math.min(1, t / 0.0004); }
  }
  return y;
}
function builtinKit(sr){
  const k = { id:'builtin', name:'Basic synth kit', builtin:true, lanes:{} };
  LANES.forEach(l => { k.lanes[l] = [{ id:'b-' + l, name:'Synth ' + LANE_NAME[l].toLowerCase(), sr, ch:[synth(l, sr)], gain:0 }]; });
  return k;
}
const HARD_KICK_ID = 'builtin-hard';
function hardKick(sr){ return { id:HARD_KICK_ID, name:'Built-in hard kick', sr, ch:[synth('hard', sr)], gain:0 }; }

/* Example break: 2 bars at 88 BPM with a lazy, late snare, swing and ghost notes. Made from the synth kit. */
function exampleLoop(sr){
  const bpm = 88, spb = 60 / bpm, bars = 2, n = Math.round(bars * 4 * spb * sr), L = new Float32Array(n), R = new Float32Array(n), rnd = mulberry(1988);
  const kit = builtinKit(sr), sw = 0.045;
  const pat = [
    ['kick', 0, 1], ['kick', 1.75, 0.7], ['kick', 2.5, 0.85], ['kick', 4, 1], ['kick', 5.5, 0.8], ['kick', 6.75, 0.75],
    ['snare', 1, 1], ['snare', 3, 1], ['snare', 5, 1], ['snare', 7, 0.95], ['snare', 2.75, 0.26], ['snare', 4.75, 0.24], ['snare', 6.25, 0.3],
    ['ohat', 7.5, 0.6]
  ];
  for (let b = 0; b < 8; b++) for (const h of [0, 0.5]){ if (b === 7 && h === 0.5) continue; pat.push(['hat', b + h, h ? 0.55 : 0.85]); }
  pat.forEach(([lane, pos, vel]) => {
    const sub = Math.round(pos * 4) % 4, late = (sub % 2 ? sw : 0) + (lane === 'snare' && vel > 0.5 ? 0.028 : 0) + (rnd() - 0.5) * 0.008;
    const at = Math.round((pos + late) * spb * sr), s = kit.lanes[lane][0].ch[0], g = Math.pow(vel, 1.4), pan = PAN[lane];
    for (let i = 0; i < s.length && at + i < n; i++){ const v = s[i] * g; L[at + i] += v * (1 - Math.max(0, pan)); R[at + i] += v * (1 + Math.min(0, pan)); }
  });
  // a little room, so slicing has real tails to deal with
  const d1 = Math.round(0.023 * sr), d2 = Math.round(0.037 * sr);
  for (let i = n - 1; i >= d2; i--){ L[i] += L[i - d1] * 0.18 + L[i - d2] * 0.1; R[i] += R[i - d2] * 0.18 + R[i - d1] * 0.1; }
  const pk = peakOf([L, R]); for (let i = 0; i < n; i++){ L[i] *= 0.89 / pk; R[i] *= 0.89 / pk; }
  return { ch:[L, R], sr, bpm, bars, name:'Example break (synthesized)' };
}

/* ---------- long beat generator ---------- */
/* Repeats the groove and adds sparse, musical changes. Locked lanes are never touched.
   Returns { events:[{pos (beats), lane, vel, id, tag}], plan:[{bar, kind, sec}], beats } */
function generateBeat(r, o){
  const R = mulberry(o.seed), B = Math.max(1, r.bars), G = grooveOf(r), p = clamp(o.amount, 0, 1), phrase = o.phrase || 8;
  const lockOf = lane => !!o.locks[LOCK_OF[lane]];
  const base = []; for (let b = 0; b < B; b++) base.push([]);
  r.hits.forEach(h => { const b = clamp(Math.floor(h.pos / 4), 0, B - 1); base[b].push({ ...h, pos:h.pos - b * 4, tag:'base' }); });
  const vAvg = lane => { const hs = r.hits.filter(h => h.lane === lane); return hs.length ? hs.reduce((s, h) => s + h.vel, 0) / hs.length : 0.7; };
  const hatV = vAvg('hat'), kickV = vAvg('kick');
  const mainSn = r.hits.filter(h => h.lane === 'snare' && h.vel >= 0.5).map(h => slotOfPos(h.pos - Math.floor(h.pos / 4) * 4));
  const events = [], plan = [];
  const pick = a => a[Math.floor(R() * a.length)];
  const at = (lane, slot) => slot / 4 + G.off(lane, ((slot % 4) + 4) % 4);
  const has = (hs, lane, slot) => hs.some(h => h.lane === lane && slotOfPos(h.pos) === slot);
  const near = (hs, lane, slot, d) => hs.some(h => h.lane === lane && Math.abs(slotOfPos(h.pos) - slot) <= d);
  const add = (hs, lane, slot, vel, tag) => { if (lockOf(lane)) return false; hs.push({ id:null, lane, pos:at(lane, slot), vel:clamp(vel, 0.05, 1), tag }); return true; };
  const addAt = (hs, lane, pos, vel, tag) => { if (lockOf(lane)) return false; hs.push({ id:null, lane, pos, vel:clamp(vel, 0.05, 1), tag }); return true; };
  const drop = (hs, test) => { let n = 0; for (let i = hs.length - 1; i >= 0; i--) if (!lockOf(hs[i].lane) && test(hs[i])){ hs.splice(i, 1); n++; } return n; };
  const trap = o.style === 'trap';
  const total = Math.max(1, o.bars);
  for (let bar = 0; bar < total; bar++){
    const hs = base[bar % B].map(h => ({ ...h }));
    const inPh = bar % phrase, phraseEnd = inPh === phrase - 1 && bar < total - 1, halfEnd = inPh === phrase / 2 - 1;
    const sec = Math.floor(bar / 16), secEnd = bar % 16 === 15 && bar < total - 1, isB = p >= 0.3 && sec % 2 === 1, secStart = bar % 16 === 0 && bar > 0;
    let kind = 'base';
    const mark = k => { if (kind === 'base' || k === 'fill' || k === 'stop' || k === 'break') kind = k; };
    if (p > 0 && bar > 0){
      /* -- small per-bar changes -- */
      if (!trap){
        if (R() < 0.22 * p){ const c = [7, 10, 14, 15, 3, 11].filter(s => !near(hs, 'kick', s, 1) && !mainSn.includes(s)); if (c.length && add(hs, 'kick', pick(c), kickV * (0.7 + R() * 0.2), 'var')) mark('var'); }
        if (R() < 0.1 * p){ if (drop(hs, h => h.lane === 'kick' && slotOfPos(h.pos) % 16 !== 0 && h.vel < 0.92 && R() < 0.5)) mark('var'); }
        if (R() < 0.4 * p){
          const c = [1, 3, 5, 7, 9, 11, 13, 15, 6, 14].filter(s => !near(hs, 'snare', s, 0) && !mainSn.includes(s));
          let k = R() < 0.18 * p ? 2 : 1; while (k-- && c.length){ const s = c.splice(Math.floor(R() * c.length), 1)[0]; if (add(hs, 'snare', s, 0.16 + R() * 0.16, 'ghost')) mark('var'); }
        }
        if (R() < 0.14 * p){ if (drop(hs, h => h.lane === 'snare' && h.vel < 0.45 && R() < 0.6)) mark('var'); }
        if (R() < 0.22 * p){ const hh = hs.filter(h => h.lane === 'hat' && slotOfPos(h.pos) % 4 !== 0); if (hh.length && !lockOf('hat')){ hs.splice(hs.indexOf(pick(hh)), 1); mark('var'); } }
        if (R() < 0.2 * p){
          const c = []; for (let s = 1; s < 16; s += 2) if (!near(hs, 'hat', s, 0) && has(hs, 'hat', s - 1) && (has(hs, 'hat', s + 1) || s === 15)) c.push(s);
          if (c.length && add(hs, 'hat', pick(c), hatV * (0.45 + R() * 0.2), 'var')) mark('var');
        }
        if (inPh % 4 === 3 && R() < 0.45 * p && !lockOf('hat')){
          const last = hs.filter(h => h.lane === 'hat' && slotOfPos(h.pos) >= 10).sort((a, b) => b.pos - a.pos)[0];
          if (last){ last.lane = 'ohat'; last.tag = 'var'; mark('var'); }
        }
        if (R() < 0.12 * p && r.hits.some(h => h.lane === 'perc')){ const c = [2, 6, 10, 14, 7, 15].filter(s => !near(hs, 'perc', s, 1)); if (c.length && add(hs, 'perc', pick(c), 0.5 + R() * 0.3, 'var')) mark('var'); }
      } else {
        if (R() < 0.3 * p){ const c = [3, 7, 10, 11, 14, 15, 6].filter(s => !near(hs, 'kick', s, 1) && !mainSn.includes(s)); if (c.length && add(hs, 'kick', pick(c), kickV * (0.75 + R() * 0.2), 'var')) mark('var'); }
        if (R() < 0.12 * p){ if (drop(hs, h => h.lane === 'kick' && slotOfPos(h.pos) % 16 !== 0 && R() < 0.5)) mark('var'); }
        if (R() < 0.12 * p){ const c = [7, 15, 13].filter(s => !near(hs, 'snare', s, 0)); if (c.length && add(hs, 'snare', pick(c), 0.25 + R() * 0.15, 'ghost')) mark('var'); }
        if (!lockOf('hat') && (R() < 0.35 * p || (phraseEnd && R() < 0.5 + 0.4 * p))){
          const beat = phraseEnd ? 3 : pick([1, 3, 3, 2]), full = phraseEnd || R() < 0.35;
          const type = pick(phraseEnd ? ['32', '32', 'trip16', 'ramp'] : ['32', 'trip16', 'trip16', 'trip8']);
          const a0 = beat + (full ? 0 : 0.5), a1 = beat + 1;
          drop(hs, h => (h.lane === 'hat' || h.lane === 'ohat') && h.pos >= a0 - 0.06 && h.pos < a1 - 0.06);
          const div = { '32':8, trip16:6, trip8:3, ramp:8 }[type], off = G.off('hat', 0);
          const pts = []; for (let k = 0; a0 + k / div < a1 - 1e-9; k++) pts.push(a0 + k / div);
          if (type === 'ramp' && full){ pts.length = 0; for (let k = 0; k < 4; k++) pts.push(beat + k / 8); for (let k = 0; k < 8; k++) pts.push(beat + 0.5 + k / 16); }
          pts.forEach((q, k) => addAt(hs, 'hat', q + off, hatV * (0.5 + 0.45 * (type === 'ramp' ? k / pts.length : (k % 2 ? 0.55 : 1))), 'roll'));
          mark(phraseEnd ? 'fill' : 'var');
        }
      }
      /* -- phrase ends: a short fill -- */
      if (phraseEnd ? R() < 0.35 + 0.6 * p : halfEnd && R() < 0.3 * p){
        const two = phraseEnd && p > 0.66 && R() < 0.4, s0 = two ? 8 : 12, kinds = [];
        if (!lockOf('snare')) kinds.push('snare', 'snare');
        if (!lockOf('kick') || !lockOf('hat')) kinds.push('drop');
        if (!lockOf('kick')) kinds.push('kick');
        if (!lockOf('hat') && !trap) kinds.push('ohat');
        const fk = kinds.length ? pick(kinds) : null;
        if (fk === 'snare'){
          drop(hs, h => h.lane === 'snare' && slotOfPos(h.pos) >= s0 && !mainSn.includes(slotOfPos(h.pos)));
          if (trap){
            if (R() < 0.5){ [12, 13, 14, 15].forEach((s, k) => add(hs, 'snare', s, 0.4 + k * 0.17, 'fill')); }
            else { for (let k = 0; k < 4; k++) addAt(hs, 'snare', 3.5 + k / 8 + G.off('snare', 2), 0.45 + k * 0.15, 'fill'); }
          } else {
            const shapes = two ? [[10, 11, 14, 15], [9, 11, 13, 14, 15]] : [[14, 15], [13, 14, 15], [15], [14]];
            const sh = pick(shapes); sh.forEach((s, k) => { if (!mainSn.includes(s)) add(hs, 'snare', s, 0.32 + 0.5 * (k + 1) / sh.length, 'fill'); });
            if (!lockOf('hat') && R() < 0.5) drop(hs, h => h.lane === 'hat' && slotOfPos(h.pos) >= s0 + 1);
          }
        } else if (fk === 'drop'){
          drop(hs, h => (h.lane === 'kick' || h.lane === 'hat' || h.lane === 'ohat') && slotOfPos(h.pos) >= (two ? 8 : 12) && slotOfPos(h.pos) < 16);
        } else if (fk === 'kick'){
          [[14, 15], [13, 15], [11, 14]][Math.floor(R() * 3)].forEach(s => { if (!near(hs, 'kick', s, 0)) add(hs, 'kick', s, kickV * 0.85, 'fill'); });
        } else if (fk === 'ohat'){
          drop(hs, h => h.lane === 'hat' && slotOfPos(h.pos) >= 14);
          if (!near(hs, 'ohat', 14, 0)) add(hs, 'ohat', 14, hatV * 0.9, 'fill');
        }
        if (fk) mark('fill');
      }
      /* -- section ends: a short stop, so the next part lands -- */
      if (secEnd && R() < 0.5 * p){
        drop(hs, h => slotOfPos(h.pos) >= 12 && slotOfPos(h.pos) < 16 && !(h.lane === 'snare' && mainSn.includes(slotOfPos(h.pos))) && !(trap && (h.lane === 'hat')));
        mark('stop');
      }
      /* -- second section: thinner first bar -- */
      if (isB && secStart){
        if (!lockOf('hat') && !trap) drop(hs, h => h.lane === 'hat' && slotOfPos(h.pos) % 2 === 1);
        if (!lockOf('kick') && p > 0.6 && R() < 0.5) drop(hs, h => h.lane === 'kick' && slotOfPos(h.pos) !== 0);
        mark('break');
      }
    }
    hs.forEach(h => events.push({ id:h.id, lane:h.lane, vel:h.vel, tag:h.tag || 'base', pos:bar * 4 + h.pos }));
    plan.push({ bar, kind, sec:isB ? 'B' : 'A' });
  }
  // the last hit: the downbeat of the first bar rings out
  base[0].filter(h => h.pos < 0.12 && (h.lane === 'kick' || h.lane === 'ohat' || h.lane === 'snare')).forEach(h => events.push({ id:h.id, lane:h.lane, vel:h.vel, tag:'end', pos:total * 4 + h.pos }));
  // humanize: small timing and level spread
  const hum = o.humanizeMs || 0, spb = 60 / o.bpm;
  if (hum > 0){ events.forEach(e => { const g = (R() + R() + R() - 1.5) / 1.5; e.pos += g * hum / 1000 / spb; e.vel = clamp(e.vel * (1 + (R() - 0.5) * 0.08), 0.05, 1); }); }
  events.sort((a, b) => a.pos - b.pos);
  // no two hits of the same lane closer than a 64th
  const out = [];
  for (const e of events){ const d = out.find(q => q.lane === e.lane && Math.abs(q.pos - e.pos) < 1 / 16); if (d){ if (e.vel > d.vel) Object.assign(d, e); } else out.push(e); }
  return { events:out, plan, beats:total * 4 };
}
/* Events for a plain loop of the rhythm (for previews). */
function loopEvents(r, times){
  const ev = [];
  for (let k = 0; k < times; k++) r.hits.forEach(h => ev.push({ id:h.id, lane:h.lane, vel:h.vel, tag:'base', pos:k * r.bars * 4 + h.pos }));
  return { events:ev.sort((a, b) => a.pos - b.pos), beats:times * r.bars * 4 };
}

/* ---------- render ---------- */
function resample(x, from, to){
  if (from === to) return x;
  const n = Math.max(1, Math.round(x.length * to / from)), y = new Float32Array(n), r = from / to;
  for (let i = 0; i < n; i++){
    const p = i * r, i0 = Math.floor(p), f = p - i0;
    const xm = x[i0 - 1] || 0, x0 = x[i0] || 0, x1 = x[i0 + 1] || 0, x2 = x[i0 + 2] || 0;
    const c1 = 0.5 * (x1 - xm), c2 = xm - 2.5 * x0 + 2 * x1 - 0.5 * x2, c3 = 0.5 * (x2 - xm) + 1.5 * (x0 - x1);
    y[i] = ((c3 * f + c2) * f + c1) * f + x0;
  }
  return y;
}
const RS_CACHE = new Map();
function soundAt(s, sr){
  if (s.sr === sr) return s.ch;
  const k = s.id + '@' + sr; if (RS_CACHE.has(k)) return RS_CACHE.get(k);
  const v = s.ch.map(c => resample(c, s.sr, sr)); RS_CACHE.set(k, v); return v;
}
const velGain = v => Math.pow(10, -26 * Math.pow(1 - clamp(v, 0, 1), 1.25) / 20);
/* Which kick hits get the layer kick. */
function layerWanted(e, L){
  if (!L || !L.on || e.lane !== 'kick') return false;
  if (L.mode === 'all') return true;
  if (L.mode === 'strong') return e.vel >= 0.7;
  if (L.mode === 'beat'){ const f = e.pos - Math.round(e.pos); return Math.abs(f) < 0.09; }
  if (L.mode === 'pick') return !!e.id && L.picked.includes(e.id.replace(/@.*/, ''));
  return false;
}
/* Mixes events with a kit. Returns {L, R} or, with only:[lanes], just those lanes. */
function renderEvents(seq, kit, opt){
  const sr = opt.sr, spb = 60 / opt.bpm, tail = opt.tail == null ? 1.6 : opt.tail;
  const n = Math.max(1, Math.round((seq.beats * spb + tail) * sr)), L = new Float32Array(n), R = new Float32Array(n);
  const fb = opt.fallback, rr = {}, only = opt.only ? new Set(opt.only) : null;
  const lane = l => { const a = kit && kit.lanes[l] && kit.lanes[l].length ? kit.lanes[l] : l === 'ohat' && kit && kit.lanes.hat && kit.lanes.hat.length ? kit.lanes.hat : fb ? fb.lanes[l] : null; return a && a.length ? a : null; };
  const ev = seq.events;
  // open hats are choked by the next hat of either kind
  const chokeAt = new Array(ev.length).fill(Infinity);
  for (let i = 0; i < ev.length; i++) if (ev[i].lane === 'ohat'){ for (let j = i + 1; j < ev.length; j++) if (ev[j].lane === 'hat' || ev[j].lane === 'ohat'){ chokeAt[i] = ev[j].pos; break; } }
  const mixIn = (chs, at, g, pan, maxLen, fadeN) => {
    const len = Math.min(chs[0].length, maxLen), gl = g * (pan > 0 ? 1 - pan : 1), gr = g * (pan < 0 ? 1 + pan : 1), c1 = chs[1] || chs[0];
    for (let i = 0; i < len; i++){
      const j = at + i; if (j < 0) continue; if (j >= n) break;
      let w = 1; const rem = len - i; if (fadeN && rem < fadeN) w = rem / fadeN;
      L[j] += chs[0][i] * gl * w; R[j] += c1[i] * gr * w;
    }
  };
  for (let i = 0; i < ev.length; i++){
    const e = ev[i], t = e.pos * spb;
    if (!only || only.has(e.lane)){
      const arr = lane(e.lane);
      if (arr){
        let s;
        if (arr.length === 1) s = arr[0];
        else if (e.lane === 'snare' && e.vel < 0.45){ s = arr.reduce((a, b) => (peakOf(a.ch) * dbToGain(a.gain || 0) <= peakOf(b.ch) * dbToGain(b.gain || 0) ? a : b)); }
        else { rr[e.lane] = ((rr[e.lane] || 0) + 1) % arr.length; s = arr[rr[e.lane]]; }
        const chs = soundAt(s, sr), at = Math.round(t * sr);
        const maxLen = chokeAt[i] < Infinity ? Math.round((chokeAt[i] - e.pos) * spb * sr) + Math.round(0.012 * sr) : Infinity;
        mixIn(chs, at, velGain(e.vel) * dbToGain((s.gain || 0) + (opt.laneDb && opt.laneDb[e.lane] || 0)), PAN[e.lane] || 0, maxLen, chokeAt[i] < Infinity ? Math.round(0.012 * sr) : 0);
      }
    }
    const Ly = opt.layer;
    if (Ly && Ly.sound && (!only || only.has('layer')) && layerWanted(e, Ly)){
      const chs = soundAt(Ly.sound, sr), at = Math.round((t + Ly.offsetMs / 1000) * sr), len = Math.round(Ly.lengthMs / 1000 * sr);
      mixIn(chs, at, dbToGain(Ly.db) * (Ly.followVel ? velGain(e.vel) : 1), 0, len, Math.min(len >> 1, Math.round(0.03 * sr)));
    }
  }
  return { L, R, n };
}
/* Glue: gentle tape-style saturation, then the peak is set to -1 dBFS. Returns the gain used. */
const ftanh = x => x <= -3 ? -1 : x >= 3 ? 1 : x * (27 + x * x) / (27 + 9 * x * x);
function master(L, R, glue, gainIn){
  const k = 1 + glue * 2.2, nk = ftanh(k), n = L.length;
  let pk = 0; for (let i = 0; i < n; i++){ const a = L[i] < 0 ? -L[i] : L[i], b = R[i] < 0 ? -R[i] : R[i]; if (a > pk) pk = a; if (b > pk) pk = b; }
  const pre = gainIn != null ? gainIn : (pk > 0 ? 0.95 / pk : 1), pk2 = pre * k;
  if (glue > 0.001){ for (let i = 0; i < n; i++){ L[i] = ftanh(L[i] * pk2) / nk; R[i] = ftanh(R[i] * pk2) / nk; } }
  else for (let i = 0; i < n; i++){ L[i] *= pre; R[i] *= pre; }
  let p2 = 0; for (let i = 0; i < n; i++){ const a = L[i] < 0 ? -L[i] : L[i], b = R[i] < 0 ? -R[i] : R[i]; if (a > p2) p2 = a; if (b > p2) p2 = b; }
  const post = p2 > 0 ? 0.891 / p2 : 1; for (let i = 0; i < n; i++){ L[i] *= post; R[i] *= post; }
  return { pre, post, k, nk };
}

/* ---------- files ---------- */
function encodeWav(chs, sr, bits = 24){
  const C = chs.length, n = chs[0].length, ba = C * bits / 8, buf = new ArrayBuffer(44 + n * ba), v = new DataView(buf);
  const str = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  str(0, 'RIFF'); v.setUint32(4, 36 + n * ba, true); str(8, 'WAVE'); str(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true);
  v.setUint16(22, C, true); v.setUint32(24, sr, true); v.setUint32(28, sr * ba, true); v.setUint16(32, ba, true); v.setUint16(34, bits, true);
  str(36, 'data'); v.setUint32(40, n * ba, true);
  let o = 44;
  for (let i = 0; i < n; i++) for (let c = 0; c < C; c++){
    const s = clamp(chs[c][i], -1, 1);
    if (bits === 24){ const q = Math.round(s < 0 ? s * 8388608 : s * 8388607); v.setUint8(o, q & 255); v.setUint8(o + 1, (q >> 8) & 255); v.setUint8(o + 2, (q >> 16) & 255); o += 3; }
    else { v.setInt16(o, Math.round(s < 0 ? s * 32768 : s * 32767), true); o += 2; }
  }
  return new Uint8Array(buf);
}
/* Reads PCM/float WAV (used for kit sounds inside project files, so no browser decoder is needed). */
function decodeWav(u8){
  const v = new DataView(u8.buffer, u8.byteOffset, u8.byteLength), tag = o => String.fromCharCode(u8[o], u8[o + 1], u8[o + 2], u8[o + 3]);
  if (tag(0) !== 'RIFF' || tag(8) !== 'WAVE') throw new Error('not wav');
  let o = 12, fmt = null;
  while (o + 8 <= u8.length){
    const id = tag(o), sz = v.getUint32(o + 4, true), d = o + 8;
    if (id === 'fmt ') fmt = { f:v.getUint16(d, true), C:v.getUint16(d + 2, true), sr:v.getUint32(d + 4, true), bits:v.getUint16(d + 14, true) };
    if (id === 'data' && fmt){
      const bps = fmt.bits / 8, n = Math.floor(sz / (bps * fmt.C)), chs = Array.from({ length:fmt.C }, () => new Float32Array(n));
      for (let i = 0; i < n; i++) for (let c = 0; c < fmt.C; c++){
        const p = d + (i * fmt.C + c) * bps; let s;
        if (fmt.f === 3) s = bps === 8 ? v.getFloat64(p, true) : v.getFloat32(p, true);
        else if (bps === 3){ let q = u8[p] | (u8[p + 1] << 8) | (u8[p + 2] << 16); if (q & 0x800000) q -= 0x1000000; s = q / 8388608; }
        else if (bps === 2) s = v.getInt16(p, true) / 32768;
        else if (bps === 4) s = v.getInt32(p, true) / 2147483648;
        else s = (u8[p] - 128) / 128;
        chs[c][i] = s;
      }
      return { ch:chs, sr:fmt.sr };
    }
    o = d + sz + (sz & 1);
  }
  throw new Error('no data');
}
/* Standard MIDI file, type 0, 960 ticks per beat so the groove survives. Channel 10, GM drum notes. */
function encodeMidi(seq, bpm, name, layer){
  const PPQ = 960, evs = [];
  seq.events.forEach(e => {
    const t = Math.max(0, Math.round(e.pos * PPQ)), v = clamp(Math.round(e.vel * 127), 1, 127);
    evs.push({ t, on:true, k:GM[e.lane], v }, { t:t + 60, on:false, k:GM[e.lane], v:0 });
    if (layer && layerWanted(e, layer)){
      const lt = Math.max(0, Math.round((e.pos + layer.offsetMs / 1000 / (60 / bpm)) * PPQ));
      evs.push({ t:lt, on:true, k:GM.layer, v:100 }, { t:lt + 60, on:false, k:GM.layer, v:0 });
    }
  });
  evs.sort((a, b) => a.t - b.t || (a.on === b.on ? 0 : a.on ? 1 : -1));
  const bytes = [], vlq = x => { const st = [x & 0x7f]; while ((x >>= 7)) st.unshift((x & 0x7f) | 0x80); bytes.push(...st); };
  const nm = Array.from(new TextEncoder().encode(name || 'Drums')).slice(0, 60);
  vlq(0); bytes.push(0xff, 0x03, nm.length, ...nm);
  const us = Math.round(60000000 / bpm); vlq(0); bytes.push(0xff, 0x51, 0x03, (us >> 16) & 255, (us >> 8) & 255, us & 255);
  vlq(0); bytes.push(0xff, 0x58, 0x04, 4, 2, 24, 8);
  let last = 0;
  evs.forEach(e => { vlq(e.t - last); last = e.t; bytes.push(e.on ? 0x99 : 0x89, e.k, e.v); });
  vlq(0); bytes.push(0xff, 0x2f, 0x00);
  const head = [0x4d, 0x54, 0x68, 0x64, 0, 0, 0, 6, 0, 0, 0, 1, (PPQ >> 8) & 255, PPQ & 255];
  const L = bytes.length, trk = [0x4d, 0x54, 0x72, 0x6b, (L >>> 24) & 255, (L >> 16) & 255, (L >> 8) & 255, L & 255];
  return new Uint8Array([...head, ...trk, ...bytes]);
}
let CRC = null;
function crc32(u8){
  if (!CRC){ CRC = new Uint32Array(256); for (let i = 0; i < 256; i++){ let c = i; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; CRC[i] = c >>> 0; } }
  let c = 0xFFFFFFFF; for (let i = 0; i < u8.length; i++) c = CRC[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0;
}
/* Stored (uncompressed) zip. files: [{name, data:Uint8Array}] → array of parts for a Blob. */
function zipParts(files){
  const enc = new TextEncoder(), parts = [], central = []; let off = 0;
  const d = new Date(), dt = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate(), tm = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
  for (const f of files){
    const name = enc.encode(f.name), data = f.data, crc = crc32(data), h = new DataView(new ArrayBuffer(30));
    h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(10, tm, true); h.setUint16(12, dt, true);
    h.setUint32(14, crc, true); h.setUint32(18, data.length, true); h.setUint32(22, data.length, true); h.setUint16(26, name.length, true);
    parts.push(new Uint8Array(h.buffer), name, data);
    const c = new DataView(new ArrayBuffer(46));
    c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(12, tm, true); c.setUint16(14, dt, true);
    c.setUint32(16, crc, true); c.setUint32(20, data.length, true); c.setUint32(24, data.length, true); c.setUint16(28, name.length, true); c.setUint32(42, off, true);
    central.push(new Uint8Array(c.buffer), name);
    off += 30 + name.length + data.length;
  }
  const cd = central.reduce((a, b) => a + b.length, 0), e = new DataView(new ArrayBuffer(22));
  e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, cd, true); e.setUint32(16, off, true);
  return [...parts, ...central, new Uint8Array(e.buffer)];
}
function b64(u8){ let s = ''; const C = 0x8000; for (let i = 0; i < u8.length; i += C) s += String.fromCharCode.apply(null, u8.subarray(i, i + C)); return btoa(s); }
function unb64(s){ const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
const packSound = s => ({ id:s.id, name:s.name, gain:s.gain || 0, from:s.from || '', wav:b64(encodeWav(s.ch, s.sr, 24)) });
function unpackSound(p){ const w = decodeWav(unb64(p.wav)); return { id:p.id || uid(), name:p.name, gain:p.gain || 0, from:p.from || '', sr:w.sr, ch:w.ch }; }
const packKit = k => ({ id:k.id, name:k.name, created:k.created, lanes:Object.fromEntries(LANES.map(l => [l, (k.lanes[l] || []).map(packSound)])) });
const unpackKit = k => ({ id:k.id, name:k.name, created:k.created || Date.now(), lanes:Object.fromEntries(LANES.map(l => [l, (k.lanes && k.lanes[l] || []).map(unpackSound)])) });

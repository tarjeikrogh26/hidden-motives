import base64,sys
import os
D=os.path.dirname(os.path.abspath(__file__))+'/'
body=open(D+'src/body.html').read()
lion=base64.b64encode(open(D+'src/lion.png','rb').read()).decode()
core=open(D+'src/core.js').read(); ui=open(D+'src/ui.js').read()
page=body+'\n<style>:root{--lion:url(data:image/png;base64,'+lion+')}</style>\n<script>\n"use strict";\n'+core+'\n'+ui+'\n</script>\n'
open(D+'artifact.html','w').write(page)
# standalone version: full document for opening outside Claude
skel='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="apple-mobile-web-app-capable" content="yes"><style>:root{color-scheme:light;box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0;padding:0;font:14px -apple-system,BlinkMacSystemFont,sans-serif}img{max-width:100%}[hidden]{display:none!important}</style></head><body>\n'
open(D+'Norwegian Breaks.html','w').write(skel+page+'</body></html>\n')
print(len(page))

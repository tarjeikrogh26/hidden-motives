/* Known-note audio fixtures, run through the actual shipped WASM + postprocessor. */
const fs=require('fs'),assert=require('assert'),C=require('./dist/chordino-runtime.js'),H=require('./dist/harmony-engine.js');
const sr=22050,D=2.8,base=[[0,'min',36],[3,'maj',39],[10,'maj',34],[5,'min',41],[8,'maj',32],[3,'maj',43],[10,'maj',38],[7,'min',31]],bytes=fs.readFileSync('dist/chordino.wasm');
function fixture(shift,cents,missing,noiseGain){const samples=new Float32Array(Math.round(sr*D*base.length)),truth=[],hz=n=>440*2**((n-69+cents/100)/12);let seed=431;const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296*2-1;};
for(let j=0;j<base.length;j++){const [r,q,b]=base[j],root=(r+shift+12)%12,bass=b+shift,start=Math.round(j*D*sr),end=Math.round((j+1)*D*sr);truth.push({start:j*D,end:(j+1)*D,root,quality:q,bass:((bass%12)+12)%12});
for(let i=start;i<end;i++){const t=(i-start)/sr;let v=0;for(const [k,d] of [0,q==='min'?3:4,7].entries())for(let h=1;h<=6;h++)v+=(k===0?.04:.06)*Math.sin(2*Math.PI*hz(60+r+shift+d)*h*t+.1*h)/h**1.5;
const beat=t%(.465),bassN=bass+(Math.floor(t/.465)===3?7:0);if(beat<.36){for(let h=missing?2:1;h<=7;h++)v+=.16*Math.exp(-beat*4)*Math.sin(2*Math.PI*hz(bassN)*h*beat)/h**1.1;}
if(beat<.16)v+=noiseGain*.19*Math.exp(-beat*24)*Math.sin(2*Math.PI*(45*beat+2*(1-Math.exp(-beat*20))));if(beat<.05)v+=noiseGain*.055*rand()*Math.exp(-beat*90);
const m=Math.floor(t/.44)%8,mt=t%.44;if(mt<.24)v+=.045*Math.exp(-mt*7)*Math.sin(2*Math.PI*hz(72+r+shift+[0,7,12,2,7,3,12,5][m])*mt);samples[i]=v;}}
return {samples,truth};}
(async()=>{const report=[];for(const [shift,cents,missing,noiseGain] of [[0,0,false,1],[2,17,false,1.3],[-3,-21,true,1]]){const {samples,truth}=fixture(shift,cents,missing,noiseGain),raw=await C.analyse(samples,sr,()=>{},bytes),result=H.finish(raw,{bpm:129,offset:0,duration:samples.length/sr});if(process.env.HARMONY_DEBUG_DIR)fs.writeFileSync(process.env.HARMONY_DEBUG_DIR+'/harmony-case-'+shift+'.json',JSON.stringify({raw,result,truth}));let n=0,roots=0,quality=0,bass=0;for(const t of truth)for(let p=t.start+.3;p<t.end-.3;p+=.04){const s=result.segments.find(s=>p>=s.start*60/129&&p<s.end*60/129);n++;roots+=!s?.silent&&s?.root===t.root;quality+=!s?.silent&&s?.quality===t.quality;const local=p-t.start,expected=(t.bass+(Math.floor(local/.465)===3?7:0))%12;bass+=s?.bass===expected;}
report.push({shift,cents,missingFundamental:missing,root:roots/n,quality:quality/n,bass:bass/n,points:n});console.log(report[report.length-1]);assert(roots/n>.92,'Root accuracy on known mixed fixture must exceed 92%');assert(bass/n>.85,'Bass line including passing fifths must exceed 85%');}
// Silence must not invent a harmonic map.
const silence=await C.analyse(new Float32Array(sr*2),sr,()=>{},bytes),empty=H.finish(silence,{bpm:120,offset:0,duration:2});assert(empty.segments.every(s=>s.silent));
console.log(JSON.stringify({passed:true,report},null,2));fs.writeFileSync('analysis/benchmark-results.json',JSON.stringify({description:'Synthetic known-note fixtures; 300ms excluded at chord boundaries. Not an accuracy score on the user song.',report},null,2));
})().catch(e=>{console.error(e);process.exit(1)});

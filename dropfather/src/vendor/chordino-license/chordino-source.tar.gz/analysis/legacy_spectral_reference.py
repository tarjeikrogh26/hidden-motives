"""Local spectral baseline. Estimates, never a verified chord transcription."""
import subprocess,json
from pathlib import Path
import numpy as np
from scipy import signal,ndimage

ROOT=Path(__file__).parent
path='/workspace/scratch/d38025f1569a/upload/TELEVISION IS BLUE 129bpm.mp3'
sr=11025; bpm=129
x=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',path,'-f','f32le','-ac','1','-ar',str(sr),'-']),dtype='<f4')
duration=len(x)/sr
nfft=8192
freq,t,z=signal.stft(x,sr,nperseg=nfft,noverlap=nfft-1024,boundary='zeros')
mag=np.abs(z).astype(np.float32)
# Horizontal persistence suppresses short broadband drum transients.
harm=ndimage.median_filter(mag,size=(1,9))
perc=ndimage.median_filter(mag,size=(17,1))
mag*=harm/(harm+perc+1e-9)
white=mag/(ndimage.uniform_filter1d(mag,size=101,axis=0)+1e-7)**0.45
white=np.sqrt(np.maximum(white,0))
peaks=(mag>np.roll(mag,1,axis=0))&(mag>=np.roll(mag,-1,axis=0))
midi=69+12*np.log2(np.maximum(freq,1)/440)
valid=(freq>65)&(freq<4000)&(np.abs(midi-np.rint(midi))<0.42)
chroma=np.zeros((12,len(t))); bass=np.zeros((12,len(t)))
for pc in range(12):
    bins=valid&(np.rint(midi).astype(int)%12==pc)
    chroma[pc]=(white[bins]*peaks[bins]).sum(axis=0)
# A low-register harmonic comb; cross-check this evidence against upper harmony.
for note in range(28,61):
    f0=440*2**((note-69)/12)
    energy=np.zeros(len(t))
    for h in range(1,6):
        k=int(round(f0*h*nfft/sr))
        energy+=np.max(white[max(1,k-1):k+2],axis=0)/(h**1.25)
    bass[note%12]=np.maximum(bass[note%12],energy)
chroma/=np.linalg.norm(chroma,axis=0)+1e-8
bass/=np.linalg.norm(bass,axis=0)+1e-8

# Only trust the title's supplied tempo; estimate its phase without changing audio.
low=mag[(freq>35)&(freq<160)].sum(axis=0)
onsets=np.maximum(0,np.diff(low,prepend=low[0]))
period=60/bpm
offsets=np.arange(0,period,0.005)
phase_scores=[]
for offset in offsets:
    beats=np.arange(offset,duration,period)
    phase_scores.append(np.interp(beats,t,onsets).sum())
offset=float(offsets[int(np.argmax(phase_scores))])
count=int(np.ceil((duration-offset)/period))
ct=[];bt=[]; loud=[]
for i in range(count):
    a=offset+i*period; b=a+period
    mask=(t>=a)&(t<b)
    c=np.mean(chroma[:,mask],axis=1) if mask.any() else chroma[:,min(len(t)-1,np.searchsorted(t,a))]
    ba=np.mean(bass[:,mask],axis=1) if mask.any() else bass[:,min(len(t)-1,np.searchsorted(t,a))]
    ct.append(c/(np.linalg.norm(c)+1e-8));bt.append(ba)
    segment=x[max(0,int(a*sr)):min(len(x),int(b*sr))]
    loud.append(float(np.sqrt(np.mean(segment**2))) if len(segment) else 0)
ct=np.array(ct);bt=np.array(bt)
# Cross-check repeated 4-bar contexts by their pitch-class sequence, not just timbre or loudness.
# The local evidence keeps 75% of its weight, so a near repeat cannot overwrite a change.
bar_starts=list(range(0,max(1,count-15),4))
features=[]
for a in bar_starts:
    block=ct[a:a+16]
    f=(block-block.mean(axis=1,keepdims=True)).reshape(-1)
    features.append(f/(np.linalg.norm(f)+1e-8))
features=np.array(features);similarity=features@features.T
ct_base=ct.copy();bt_base=bt.copy();repeat_links=[]
for bi,a in enumerate(bar_starts):
    candidates=[j for j,b in enumerate(bar_starts) if abs(b-a)>=32 and similarity[bi,j]>=.94]
    candidates=sorted(candidates,key=lambda j:similarity[bi,j],reverse=True)[:2]
    if not candidates: continue
    repeat_links.append({'start':a,'matches':[bar_starts[j] for j in candidates],'similarity':round(float(similarity[bi,candidates[0]]),3)})
    for k in range(min(4,count-a)):
        ct[a+k]=.75*ct_base[a+k]+.25*np.mean([ct_base[bar_starts[j]+k] for j in candidates],axis=0)
        bt[a+k]=.85*bt_base[a+k]+.15*np.mean([bt_base[bar_starts[j]+k] for j in candidates],axis=0)

types={'maj':[0,4,7],'min':[0,3,7],'sus2':[0,2,7],'sus4':[0,5,7],'dim':[0,3,6]}
states=[];templates=[]
for quality,intervals in types.items():
    for root in range(12):
        template=np.ones(12)*0.05
        for interval,weight in zip(intervals,[1,0.85,0.75]): template[(root+interval)%12]=weight
        templates.append(template/np.linalg.norm(template));states.append((root,quality))
scores=ct@np.array(templates).T
for j,(root,quality) in enumerate(states):
    scores[:,j]+=0.16*bt[:,root]
    if quality.startswith('sus'):scores[:,j]-=0.04
    if quality=='dim':scores[:,j]-=0.06
# Viterbi smoothing: refrain from switching label on every fleeting melody tone.
dp=scores[0].copy();backs=[]
transition=np.full((len(states),len(states)),0.075)
np.fill_diagonal(transition,0)
for i in range(1,count):
    candidates=dp[:,None]-transition
    back=np.argmax(candidates,axis=0);backs.append(back)
    dp=scores[i]+candidates[back,np.arange(len(states))]
pathidx=[int(np.argmax(dp))]
for back in backs[::-1]:pathidx.append(int(back[pathidx[-1]]))
pathidx.reverse()
# Bass is a separate timeline. A chord staying the same does not imply a constant bass note.
bass_path=np.argmax(ndimage.uniform_filter1d(bt,size=3,axis=0,mode='nearest'),axis=1)
segments=[]
for i,idx in enumerate(pathidx):
    root,quality=states[idx]; ranked=np.sort(scores[i]); margin=float(ranked[-1]-ranked[-2])
    # This number indicates separation between spectral candidates, not accuracy probability.
    clarity=min(1,max(0,margin*12))
    silent=loud[i]<0.003
    if segments and segments[-1]['root']==root and segments[-1]['quality']==quality and segments[-1]['bass']==int(bass_path[i]) and segments[-1]['silent']==silent:
        segments[-1]['end']=i+1;segments[-1]['clarity']=min(segments[-1]['clarity'],round(clarity,3))
    else:segments.append({'start':i,'end':i+1,'root':root,'quality':quality,'bass':int(bass_path[i]),'clarity':round(clarity,3),'silent':bool(silent),'edited':False})
wave=[]
for chunk in np.array_split(x,1600):wave.append(round(float(np.max(np.abs(chunk))),4) if len(chunk) else 0)
result={'title':'TELEVISION IS BLUE','bpm':bpm,'offset':round(offset,4),'duration':duration,'segments':segments,'waveform':wave,'repeatLinks':repeat_links,'method':'Multi-band chroma + separate bass timeline + repeated-context cross-check + temporal smoothing; experimental, not verified','verified':False}
(ROOT/'dist/assets/reference.json').write_text(json.dumps(result,separators=(',',':')))
print(json.dumps({'duration':duration,'offset':offset,'segments':len(segments),'repeatLinks':len(repeat_links),'lowClarity':sum(s['clarity']<0.35 for s in segments)}))

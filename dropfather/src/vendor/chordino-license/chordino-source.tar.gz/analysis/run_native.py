"""Development harness for the same Chordino core shipped as WebAssembly."""
import ctypes,json,subprocess,sys,time
from pathlib import Path
import numpy as np
from scipy.fft import rfft
ROOT=Path(__file__).resolve().parents[1]
LIB=ctypes.CDLL('/workspace/scratch/d38025f1569a/libchordino.so')
LIB.chord_init.argtypes=[ctypes.c_int]*3;LIB.chord_input.restype=ctypes.POINTER(ctypes.c_float);LIB.chord_frame.argtypes=[ctypes.c_double];LIB.chord_result.restype=ctypes.c_char_p
SR=22050;BLOCK=16384;HOP=2048

def analyse(x):
 assert LIB.chord_init(SR,BLOCK,HOP)
 buf=np.ctypeslib.as_array(LIB.chord_input(),shape=(BLOCK+2,));win=np.hanning(BLOCK).astype(np.float32);pad=np.pad(x,(BLOCK//2,BLOCK//2));t0=time.time()
 for frame in range(0,len(x),HOP):
  spectrum=rfft(pad[frame:frame+BLOCK]*win);buf[0::2]=spectrum.real;buf[1::2]=spectrum.imag;LIB.chord_frame(frame/SR)
 LIB.chord_finish();data=json.loads(LIB.chord_result());LIB.chord_dispose();print('Chordino:',len(data['frames']),'frames',round(time.time()-t0,2),'sec',file=sys.stderr);return data

if __name__=='__main__':
 path=sys.argv[1] if len(sys.argv)>1 else '/workspace/scratch/d38025f1569a/upload/TELEVISION IS BLUE 129bpm.mp3'
 x=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',path,'-f','f32le','-ac','1','-ar',str(SR),'-']),dtype='<f4');data=analyse(x)
 target=sys.argv[2] if len(sys.argv)>2 else '/workspace/scratch/d38025f1569a/chordino-reference-raw.json';Path(target).write_text(json.dumps(data,separators=(',',':')))
 print(json.dumps({'chords':data['chords'][:45],'count':len(data['chords'])}))

// Chordino C API adaptation, GPL-2.0-or-later; see chordino/COPYING.
#include "chordino/Chordino.h"
#include <sstream>
#include <iomanip>
#include <vector>
#include <string>
static Chordino *engine=nullptr;
static std::vector<float> input;
static std::string output;
extern "C" {
void chord_dispose(){delete engine;engine=nullptr;input.clear();output.clear();}
int chord_init(int sr,int block,int hop){chord_dispose();engine=new Chordino(sr);engine->getOutputDescriptors();input.resize(block+2);return engine->initialise(1,hop,block);}
float* chord_input(){return input.data();}
void chord_frame(double t){const float* ptr=input.data();engine->process(&ptr,Vamp::RealTime::fromSeconds(t));}
int chord_finish(){auto f=engine->getRemainingFeatures();std::ostringstream s;s<<std::setprecision(7)<<"{\"chords\":[";bool comma=false;for(auto &x:f[0]){if(comma)s<<",";comma=true;s<<"["<<Vamp::RealTime::realTime2Frame(x.timestamp,22050)/22050.0<<",\""<<x.label<<"\"]";}s<<"],\"frames\":[";comma=false;for(size_t i=0;i<f[4].size();i++){if(comma)s<<",";comma=true;s<<"["<<Vamp::RealTime::realTime2Frame(f[4][i].timestamp,22050)/22050.0;for(float x:f[4][i].values)s<<","<<x;for(float x:f[5][i].values)s<<","<<x;s<<"]";}s<<"]}";output=s.str();return output.size();}
const char* chord_result(){return output.c_str();}
}

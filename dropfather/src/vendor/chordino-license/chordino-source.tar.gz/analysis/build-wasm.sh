#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python -m ziglang c++ -target wasm32-wasi -mexec-model=reactor -std=c++17 -O2 -fno-exceptions -fno-rtti -Ianalysis/vamp analysis/chordino-bridge.cpp analysis/chordino/Chordino.cpp analysis/chordino/NNLSBase.cpp analysis/chordino/chromamethods.cpp analysis/chordino/viterbi.cpp -x c++ analysis/chordino/nnls.c analysis/vamp/RealTime.cpp -Wl,--export=chord_init -Wl,--export=chord_input -Wl,--export=chord_frame -Wl,--export=chord_finish -Wl,--export=chord_result -Wl,--export=chord_dispose -Wl,--export-memory -Wl,--strip-all -Wl,-z,stack-size=1048576 -o dist/chordino.wasm

"""Known-note, mixed-audio fixtures. No claimed ground truth for the user's song."""
import sys,json
from pathlib import Path
import numpy as np
from run_native import analyse,SR
rng=np.random.default_rng(431)
freq=lambda n:440*2**((n-69)/12)
# Roots change, with melodic non-chord notes, offbeat bass fifths and slash basses.
progression=[(0,'min',36),(3,'maj',39),(10,'maj',34),(5,'min',41),(8,'maj',32),(3,'maj',43),(10,'maj',38),(7,'min',31)]
D=3.72;x=np.zeros(int(SR*D*len(progression)),dtype=np.float32);truth=[]
for j,(root,q,bass) in enumerate(progression):
 a=int(j*D*SR);b=int((j+1)*D*SR);t=np.arange(b-a)/SR;y=np.zeros_like(t)
 # Sustained three-note synth chord, with harmonics and a stronger third than root.
 intervals=[0,3 if q=='min' else 4,7]
 for k,d in enumerate(intervals):
  n=60+root+d;y+=(.045 if k==0 else .065)*sum(np.sin(2*np.pi*freq(n)*h*t+.1*h)/h**1.5 for h in range(1,7))
 # Bass pulse at 129 BPM, includes a short fifth; first fundamental can be missing.
 for beat in np.arange(0,D,.465):
  at=int(beat*SR);dur=min(int(.36*SR),len(t)-at);u=np.arange(dur)/SR;n=bass+(7 if 1.3<beat<1.6 else 0)
  y[at:at+dur]+=.16*np.exp(-u*4)*sum(np.sin(2*np.pi*freq(n)*h*u)/h**1.1 for h in range(1,8))
  # Untuned kick plus snare/hat transients.
  kd=min(int(.16*SR),len(t)-at);u=np.arange(kd)/SR;y[at:at+kd]+=.19*np.exp(-u*24)*np.sin(2*np.pi*(45*u+2*(1-np.exp(-u*20))))
  ha=min(int(.05*SR),len(t)-at);y[at:at+ha]+=.04*rng.normal(size=ha)*np.exp(-np.arange(ha)/SR*90)
 for k in range(8):
  at=int(k*.44*SR);dur=min(int(.24*SR),len(t)-at);u=np.arange(dur)/SR;n=72+root+[0,7,12,2,7,3,12,5][k];y[at:at+dur]+=.04*np.exp(-u*7)*np.sin(2*np.pi*freq(n)*u)
 x[a:b]=y;truth.append({'start':j*D,'end':(j+1)*D,'root':root,'quality':q,'bass':bass%12})
raw=analyse(x);out=Path('/workspace/scratch/d38025f1569a/harmony-benchmark.json');out.write_text(json.dumps({'raw':raw,'truth':truth,'duration':len(x)/SR}))
print(json.dumps(raw['chords']))
